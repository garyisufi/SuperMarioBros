﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using wildcats_sprint1.Window;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Window
{
    public class Layer
    {
        public Layer(Camera camera)
        {
            _camera = camera;
            Parallax = Vector2.One;
            objs = new List<GameObject>();
        }

        public Vector2 Parallax { get; set; }
        public List<GameObject> objs { get; private set; }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, _camera.GetViewMatrix(Parallax));
            foreach (GameObject obj in objs)
                obj.Draw(spriteBatch);
            spriteBatch.End();
        }

        private readonly Camera _camera;
    }
}
