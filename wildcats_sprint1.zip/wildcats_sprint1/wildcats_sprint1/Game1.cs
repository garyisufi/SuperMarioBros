﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Command_Handling;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Levels;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.Block;
using wildcats_sprint1.Objects.Enemy;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.Score;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.SpriteClasses.Factories;
using wildcats_sprint1.States.Powerups;
using wildcats_sprint1.Window;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using static wildcats_sprint1.SpriteClasses.Factories.ItemSpriteFactory;

namespace wildcats_sprint1
{
    
    /// <summary>
    /// Sprint 1 for Team Wildcats
    /// Andrew, Joseph, Gary, Tyler, Jason
    /// </summary>
    public class Game1 : Game
    {
        public static Game1 Game { get; private set; }

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        List<Controller> controllers;
        List<Controller> pauseControllers;
        public Mario mario;
        List<TileMap.EnemyData> enemyList;
        List<TileMap.ItemData> itemList;
        List<TileMap.BlockData> blockList;
        List<CoinMap.BlockData> coinBlockList;
        List<CoinMap.ItemData> coinItemList;
        List<TileMap.Background> backList;
        List<TileMap.PipeData> pipeList;
        List<TileMap.QuestionBlockData> qList;
        List<TileMap.BrickBlockData> bList;
        TileMap.MarioData marioData;
        CoinMap.MarioData marioCoinData;
        ItemSpriteFactory itemFact;
        BlockSpriteFactory blockFact;
        EnemySpriteFactory enemyFact;
        MarioSpriteFactory marioFact;
        BackgroundSpriteFactory backFact;
        public List<GameObject> Objects { get; set; }
        public Grid grid { get; set; }
        RenderTarget2D renderTarget;
        Texture2D shadowMap;
        Camera camera;
        public List<Layer> layers { get; set; }
        private List<Item> iList;
        //Environment Sprites
        int initialMarioXPos;
        int initialMarioYPos;
        bool showBorders;
        WarpPipe pipe;
        public int numResets;
        public int allowedResets;
        public int score;
        Song song;
        bool isPaused;
        Scoreboard scoreboard;
        private SoundEffect mySound;
        public int EndLevel;
        
        public Game1()
        {
            Game = this;
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            controllers = new List<Controller>();
            pauseControllers = new List<Controller>();
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 960;
            graphics.ApplyChanges();
            renderTarget = new RenderTarget2D(graphics.GraphicsDevice, 3584, 240);
            numResets = 0;
            allowedResets = 3;
            isPaused = false;
            EndLevel = 3250;
            
        }


        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            Objects = new List<GameObject>();
            controllers.Add(new KeyboardController(this));
            controllers.Add(new GamepadController(this));
            controllers.Add(new GamepadControllerPlayer2(this));
            controllers.Add(new GamepadControllerPlayer3(this));
            controllers.Add(new GamepadControllerPlayer4(this));
            pauseControllers.Add(new KeyboardController(this));
            pauseControllers.Add(new GamepadController(this));
            pauseControllers.Add(new GamepadControllerPlayer2(this));
            pauseControllers.Add(new GamepadControllerPlayer3(this));
            pauseControllers.Add(new GamepadControllerPlayer4(this));
            iList = new List<Item>();
            graphics.GraphicsDevice.Viewport = new Viewport(new Rectangle(0, 0, 256, 240));
            camera = new Camera(graphics.GraphicsDevice.Viewport);
            camera.Limits = new Rectangle(new Point(0, 0), new Point(3584, 240));
            layers = new List<Layer>
                {
                    new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                    new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                    new Layer(camera) { Parallax = new Vector2(0.5f, 1.0f) },
                };

            base.Initialize();
            #region Declare Environment textures

            #endregion
            foreach (Controller controller in controllers)
            {
                if (controller is KeyboardController)
                {
                    #region Keyboard Controller Command Mapping
                    controller.Command((int)Keys.Q, new ExitCommand(this));
                    controller.Command((int)Keys.P, new PauseCommand(this));



                    // Crouch / Stand
                    controller.Command((int)Keys.S, new MarioCrouchCommand(mario));
                    controller.Command((int)Keys.S, new MarioCrouchDiscontinueCommand(mario), (int)Controller.Action.Released);
                    controller.Command((int)Keys.Down, new MarioCrouchCommand(mario));
                    controller.Command((int)Keys.Down, new MarioCrouchDiscontinueCommand(mario), (int)Controller.Action.Released);

                    // Jump / Fall
                    controller.Command((int)Keys.W, new MarioJumpCommand(mario));
                    controller.Command((int)Keys.W, new MarioJumpCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.W, new MarioJumpDiscontinueCommand(mario), (int)Controller.Action.Released);
                    controller.Command((int)Keys.Up, new MarioJumpCommand(mario));
                    controller.Command((int)Keys.Up, new MarioJumpCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.Up, new MarioJumpDiscontinueCommand(mario), (int)Controller.Action.Released);

                    // Face Left / Walk / Run / Walk / Stand
                    controller.Command((int)Keys.A, new MarioFaceLeftCommand(mario));
                    controller.Command((int)Keys.A, new MarioFaceLeftCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.A, new MarioFaceLeftDiscontinueCommand(mario), (int)Controller.Action.Released);
                    controller.Command((int)Keys.Left, new MarioFaceLeftCommand(mario));
                    controller.Command((int)Keys.Left, new MarioFaceLeftCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.Left, new MarioFaceLeftDiscontinueCommand(mario), (int)Controller.Action.Released);

                    // Face Right / Walk / Run / Walk / Stand
                    controller.Command((int)Keys.D, new MarioFaceRightCommand(mario));
                    controller.Command((int)Keys.D, new MarioFaceRightCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.D, new MarioFaceRightDiscontinueCommand(mario), (int)Controller.Action.Released);
                    controller.Command((int)Keys.Right, new MarioFaceRightCommand(mario));
                    controller.Command((int)Keys.Right, new MarioFaceRightCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Keys.Right, new MarioFaceRightDiscontinueCommand(mario), (int)Controller.Action.Released);

                    // Cheats - PowerUps
                    controller.Command((int)Keys.Y, new MarioStandardStateCommand(mario));
                    controller.Command((int)Keys.U, new MarioSuperStateCommand(mario));
                    controller.Command((int)Keys.I, new MarioFireStateCommand(mario));
                    controller.Command((int)Keys.J,  new MarioStarStateCommand(mario));
                    controller.Command((int)Keys.K,  new MarioSuperStarStateCommand(mario));
                    controller.Command((int)Keys.O, new MarioTakeDamageCommand(mario));
                    controller.Command((int)Keys.R, new ResetCommand(this));
                    controller.Command((int)Keys.B, new ShowSpriteBordersCommand(this));
                    controller.Command((int)Keys.RightShift, new FireballCommand(this));
                    controller.Command((int)Keys.M, new MuteCommand(this));
                    #endregion
                }
                else
                if (controller is GamepadController)
                {
                    #region Gamepad Controller Cmmand Mapping
                    controller.Command((int)Buttons.Start, new ExitCommand(this));
                    controller.Command((int)Buttons.A, new MarioJumpCommand(mario));
                    controller.Command((int)Buttons.A, new MarioFaceRightCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Buttons.A, new MarioFaceRightDiscontinueCommand(mario), (int)Controller.Action.Released);
                    
                    controller.Command((int)Buttons.DPadRight, new MarioFaceRightCommand(mario));
                    controller.Command((int)Buttons.DPadRight, new MarioFaceRightCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Buttons.DPadRight, new MarioFaceRightDiscontinueCommand(mario), (int)Controller.Action.Released);
                    
                    controller.Command((int)Buttons.DPadLeft, new MarioFaceLeftCommand(mario));
                    controller.Command((int)Buttons.DPadLeft, new MarioFaceLeftCommand(mario), (int)Controller.Action.Held);
                    controller.Command((int)Buttons.DPadLeft, new MarioFaceLeftDiscontinueCommand(mario), (int)Controller.Action.Released);
                    
                    controller.Command((int)Buttons.DPadDown, new MarioCrouchCommand(mario));
                    controller.Command((int)Buttons.DPadDown, new MarioCrouchDiscontinueCommand(mario), (int)Controller.Action.Released);

                    controller.Command((int)Buttons.B, new MarioThrowProjectileCommand(mario));
                    controller.Command((int)Buttons.Y, new MarioSuperStateCommand(mario));
                    controller.Command((int)Buttons.X, new MarioStarStateCommand(mario));
                    controller.Command((int)Buttons.Back, new MarioTakeDamageCommand(mario));
                    controller.Command((int)Buttons.DPadUp, new MarioStandardStateCommand(mario));
                    controller.Command((int)Buttons.LeftTrigger, new MarioFireStateCommand(mario));
                    #endregion
                }
            }
            foreach(Controller controller in pauseControllers)
            {
                if(controller is KeyboardController)
                {
                    controller.Command((int)Keys.P, new PauseCommand(this));
                    //In future put buttons to allow pause menu selection here

                }
                else if(controller is GamepadController)
                {
                    //In future put buttons to allow pause menu selection here
                }
            }
            scoreboard = new Scoreboard(spriteBatch, graphics);




        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(graphics.GraphicsDevice);
            LevelLoader level = new LevelLoader();
            CoinLoader coin = new CoinLoader();
            this.song = Content.Load<Song>("Sounds/spidey");
            MediaPlayer.Play(song);
            LoadLevel1();
            marioData = level.LoadMario();
            marioCoinData = coin.LoadMario();
            marioFact = new MarioSpriteFactory();
            Sprite mar = marioFact.GenerateSprite(marioData.State, marioData.xLocation, marioData.yLocation, marioData.Flipped == 0);
            mario = new Mario(new Vector2(marioData.xLocation, marioData.yLocation), mar);
            initialMarioXPos = marioData.xLocation;
            initialMarioYPos = marioData.yLocation;
            layers[0].objs.Add(mario);
            
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
            Content.Unload();
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (scoreboard.time == 0)
            {
                allowedResets = 0;
            }
            if (isPaused)
            {
                MediaPlayer.Pause();
                foreach (Controller controller in pauseControllers)
                {
                    controller.UpdateInput();
                }
            }
            else
            {
                MediaPlayer.Resume();
                List<GameObject> objs = grid.PossibleCollisions((int)mario.Position.X, (int)mario.Position.Y);
                List<GameObject> collisions = new List<GameObject>();
                foreach(GameObject obj in objs)
                {
                    if (mario.detector.DetectCollision(obj, gameTime))
                    {
                        (mario.collider).ExecuteCollision(obj, mario.detector.CollisionDirection());
                    }
                }
                foreach (GameObject obj in Objects)
                {
                    if (obj.Position.X + obj.width > camera.Position.X && obj.Position.X < camera.Position.X + 256)
                    {
                        List<GameObject> objs2 = grid.PossibleCollisions((int)obj.Position.X, (int)obj.Position.Y);
                        foreach (GameObject obj2 in objs2)
                        {
                            if (obj.detector != null)
                            {
                                if (obj.detector.DetectCollision(obj2, gameTime))
                                {

                                    obj.collider.ExecuteCollision(obj2, obj.detector.CollisionDirection());
                                }
                            }
                        }
                        grid.Remove(obj);
                        obj.Update(gameTime, graphics);
                        foreach (Item i in iList)
                        {
                            if (i.isFullyRevealed)
                            {
                                if (layers[1].objs.Contains(i))
                                {
                                    layers[1].objs.Remove(i);
                                    layers[0].objs.Add(i);
                                }
                            }
                        }
                        if (obj.Position.X + obj.width > camera.Position.X && obj.Position.X < camera.Position.X + 256)
                            grid.Add(obj);
                    }
                }
                mario.Update(gameTime, graphics);
                camera.LookAt(new Vector2(mario.Position.X, 136));
                camera.Limits = new Rectangle(new Point((int)camera.Position.X, 0), new Point(3584 - (int)camera.Position.X, 256));
                mario.leftBound = (int)camera.Position.X;

                foreach (Controller controller in controllers)
                {
                    controller.UpdateInput();
                }
                scoreboard.Update(gameTime);
                base.Update(gameTime);
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.SetRenderTarget(renderTarget);
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            layers[2].Draw(spriteBatch);
            layers[1].Draw(spriteBatch);
            layers[0].Draw(spriteBatch);

            spriteBatch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, camera.GetViewMatrix(layers[0].Parallax));

            spriteBatch.End();
            if (allowedResets <= 0)
            {
                Console.WriteLine("Game Over screen");
                Texture2D bkrnd = Content.Load<Texture2D>("gameOver");
                Rectangle mainFrame = new Rectangle(0, 0, 256, 256);
                MediaPlayer.Stop();
                spriteBatch.Begin();
                spriteBatch.Draw(bkrnd, mainFrame, Color.White);
                spriteBatch.End();
                MediaPlayer.Play(this.song);
            }
            if (mario.Position.X >= EndLevel)
            {
                Console.WriteLine("Victory screen");
                Texture2D bkrnd = Content.Load<Texture2D>("Victory");
                Rectangle mainFrame = new Rectangle(0, 0, 256, 256);
                MediaPlayer.Stop();
                spriteBatch.Begin();
                spriteBatch.Draw(bkrnd, mainFrame, Color.White);
                spriteBatch.End();
                MediaPlayer.Play(this.song);
            }

            graphics.GraphicsDevice.SetRenderTarget(null);
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            shadowMap = (Texture2D)renderTarget;
            spriteBatch.Draw(shadowMap, new Vector2(0, 0), null, Color.White, 0, new Vector2(0, 0), 4.0f, SpriteEffects.None, 1);
            spriteBatch.End();
            scoreboard.Draw();
            base.Draw(gameTime);
        }
        public void ExitCommand()
        {
            this.Exit();
        }

        public void resetResets()
        {
            numResets = 0;
            allowedResets = 3;
        }

        public void ShowSpriteBordersCommand()
        {
            Boxes();
        }

        
        public void CollisionCommand()
        {
        }
        public void Boxes()
        {
            foreach (GameObject obj in Objects)
            {
                obj.Sprite.DrawAABB = !obj.Sprite.DrawAABB;
            }
            Mario.displayBorder = !Mario.displayBorder;
        }

        public void ResetCommand(bool isCoinRoom)
        {
            if (!layers[0].objs.Contains(mario))
            {
                layers[0].objs.Add(mario);
            }
            mario.isVictory = false;
            Scoreboard.getInstance().score = 0;
            mario.deathReset = false;
            if (allowedResets == 0)
            {
                allowedResets = 3;
                numResets = 0;
                mario.detector.Collidable = true;
                if (numResets < 3)
                {
                    if (showBorders)
                    {
                        Boxes();
                    }
                    layers = new List<Layer>
                {
                    new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                    new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                    new Layer(camera) { Parallax = new Vector2(0.5f, 1.0f) },
                };
                    Objects.Clear();
                    itemList.Clear();
                    blockList.Clear();
                    enemyList.Clear();
                    LoadLevel1();
                    camera.Limits = new Rectangle(new Point(0, 0), new Point(3584, 240));
                    mario.ChangeToStandardState();
                    mario.ChangeToStanding();
                    mario.Sprite.Direction = eDirection.Right;
                    mario.Sprite.AABB.Acceleration = new Vector2(0, 0);
                    mario.leftBound = 0;
                    mario.Position = new Vector2(initialMarioXPos, initialMarioYPos);
                    mario.Sprite.AABB.Velocity = new Vector2(0, 0);
                }

            } else
            {
                numResets++;
                allowedResets--;
                Console.WriteLine("Reset");
                MediaPlayer.Play(this.song);
                mario.detector.Collidable = true;
                if (numResets < 3)
                {
                    if (showBorders)
                    {
                        Boxes();
                    }
                    layers = new List<Layer>
                    {
                        new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                        new Layer(camera) { Parallax = new Vector2(1.0f, 1.0f) },
                        new Layer(camera) { Parallax = new Vector2(0.5f, 1.0f) },
                    };
                    Objects.Clear();
                    itemList.Clear();
                    blockList.Clear();
                    enemyList.Clear();
                    if (!isCoinRoom)
                    {
                        LoadLevel1();
                        camera.Limits = new Rectangle(new Point(0, 0), new Point(3584, 240));
                        mario.ChangeToStandardState();
                        mario.ChangeToStanding();
                        mario.Sprite.Direction = eDirection.Right;
                        mario.Sprite.AABB.Acceleration = new Vector2(0, 0);
                        mario.leftBound = 0;
                        mario.Position = new Vector2(initialMarioXPos, initialMarioYPos);
                        mario.Sprite.AABB.Velocity = new Vector2(0, 0);
                    }
                    else
                    {
                        LoadCoinRoom();
                        camera.Limits = new Rectangle(new Point(0, 0), new Point(3584, 240));
                        mario.ChangeToStandardState();
                        mario.ChangeToFalling();
                        mario.Sprite.Direction = eDirection.Right;
                        mario.Sprite.AABB.Acceleration = new Vector2(0, 0);
                        mario.leftBound = 0;
                        mario.Position = new Vector2(32, 32);
                        mario.Sprite.AABB.Velocity = new Vector2(0, 0);
                    }
                    
                }
            }


            
        }
        public void FireballCommand()
        {
            if (Game1.Game.mario.isFire) {
                ItemSpriteFactory sprite = new ItemSpriteFactory();
                Console.WriteLine("Fireball!");
                //Fireball fireball = new Fireball(Game1.Game.mario.Position, sprite.GenerateSprite(5, (int)Game1.Game.mario.Position.X, (int)Game1.Game.mario.Position.Y));
                Sprite sprite2 = itemFact.GenerateSprite(5, (int)Game1.Game.mario.Position.X, (int)Game1.Game.mario.Position.X);
                Fireball fireball = new Fireball(Game1.Game.mario.Position, sprite2);
                layers[0].objs.Add(fireball);
                Objects.Add(fireball);
                grid.Add(fireball);
            }
            
        }

        public void MuteCommand()
        {
            MediaPlayer.IsMuted =  !MediaPlayer.IsMuted;
            if (SoundEffect.MasterVolume == 0.0f)
            {
                SoundEffect.MasterVolume = 1.0f;
            }
            else
            {
                SoundEffect.MasterVolume = 0.0f;
            }
                
        }
        public void MarioAnimatedPipe()
        {
            layers[0].objs.Remove(mario);
            layers[1].objs.Add(mario);
            mario.isDownPipe = 32;
            mario.detector.Collidable = false;
        }

        public void LoadLevel1()
        {
            LevelLoader level = new LevelLoader();
            grid = new Grid(3800, 640);
            enemyList = level.LoadEnemies();
            enemyFact = new EnemySpriteFactory();
            foreach (TileMap.EnemyData enemy in enemyList)
            {
                Sprite sprite = enemyFact.GenerateSprite(enemy.State, enemy.xLocation, enemy.yLocation);
                GameObject gameObject = new Enemy(sprite.Position, (EnemySprite)sprite);
                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }

            itemList = level.LoadItems();
            itemFact = new ItemSpriteFactory();
            foreach (TileMap.ItemData item in itemList)
            {
                Sprite sprite = itemFact.GenerateSprite(item.State, item.xLocation, item.yLocation);
                GameObject gameObject = new Item(sprite.Position, (ItemSprite)sprite);
                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
            backList = level.LoadBackground();
            backFact = new BackgroundSpriteFactory();
            foreach (TileMap.Background item in backList)
            {
                Sprite sprite = backFact.GenerateSprite(item.State, item.xLocation, item.yLocation);
                GameObject gameObject = new GameObject(sprite.Position, sprite);
                layers[2].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
            qList = level.LoadQuestionBlocks();
            blockFact = new BlockSpriteFactory();
            foreach (TileMap.QuestionBlockData item in qList)
            {
                Sprite sprite = blockFact.GenerateSprite(item.State, item.xLocation, item.yLocation);
                Sprite itemSprite = itemFact.GenerateSprite(item.containedItem, item.xLocation, item.yLocation);
                Item i = null;
                if (item.containedItem == 0)
                {
                    i = new GreenMushroom(itemSprite.Position, (ItemSprite)itemSprite);
                }
                if (item.containedItem == 1)
                {
                    i = new RedMushroom(itemSprite.Position, (ItemSprite)itemSprite);
                }
                if (item.containedItem == 2)
                {
                    i = new FireFlower(itemSprite.Position, (ItemSprite)itemSprite);
                }
                if (item.containedItem == 3)
                {
                    i = new Star(itemSprite.Position, (ItemSprite)itemSprite);
                }
                if (item.containedItem == 4)
                {
                    i = new Coin(itemSprite.Position, (ItemSprite)itemSprite, true);
                }

                GameObject gameObject = new QuestionBlock(sprite.Position, (BlockSprite)sprite, item.isHidden == 1, i);
                layers[0].objs.Add(gameObject);
                layers[1].objs.Add(i);
                Objects.Add(gameObject);
                Objects.Add(i);
                grid.Add(gameObject);
                grid.Add(i);
                iList.Add(i);
            }
            blockList = level.LoadBlocks();

            foreach (TileMap.BlockData block in blockList)
            {
                GameObject gameObject;
                Sprite sprite = blockFact.GenerateSprite(block.State, block.xLocation, block.yLocation);
                if (block.State == 0)
                {
                    gameObject = new BrickBlockObject(sprite.Position, (BrickBlock)sprite, false, 0, null);
                }
                else
                {
                    gameObject = new BlockObject(sprite.Position, (BlockSprite)sprite);
                }
                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
            bList = level.LoadBrickBlocks();
            foreach (TileMap.BrickBlockData item in bList)
            {
                Sprite sprite = blockFact.GenerateSprite(item.State, item.xLocation, item.yLocation);
                Sprite itemSprite = itemFact.GenerateSprite((int)ItemSpriteID.Coin, item.xLocation, item.yLocation);
                Coin c = null;
                if (item.numCoins > 0)
                {
                    c = new Coin(new Vector2(item.xLocation, item.yLocation), (ItemSprite)itemSprite, true);
                }
                GameObject gameObject = new BrickBlockObject(sprite.Position, (BrickBlock)sprite, item.isHidden == 1, item.numCoins, c);
                layers[0].objs.Add(gameObject);

                Objects.Add(gameObject);
                grid.Add(gameObject);
                if (item.numCoins > 0)
                {
                    layers[1].objs.Add(c);
                    grid.Add(c);
                    iList.Add(c);
                }
            }
            pipeList = level.LoadPipes();
            foreach (TileMap.PipeData pipe in pipeList)
            {
                GameObject gameObject;
                Sprite sprite = blockFact.GenerateSprite(6, pipe.xLocation, pipe.yLocation);
                Piranha p = null;
                if(pipe.piranha==1)
                {

                    p = new Piranha(new Vector2(pipe.xLocation, pipe.yLocation + 16),(EnemySprite) enemyFact.GenerateSprite(3, pipe.xLocation, pipe.yLocation + 16));
                    layers[1].objs.Add(p);
                    Objects.Add(p);
                    grid.Add(p);
                }
                    gameObject = new WarpPipe(sprite.Position, (BlockSprite)blockFact.GenerateSprite(6, pipe.xLocation, pipe.yLocation),p, pipe.isTele);

                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
        }
        public void LoadCoinRoom()
        {
            layers[1].objs.Remove(mario);
            layers[0].objs.Add(mario);
            CoinLoader level = new CoinLoader();
            grid = new Grid(256,224);

            coinItemList = level.LoadItems();
            itemFact = new ItemSpriteFactory();
            foreach (CoinMap.ItemData item in coinItemList)
            {
                Sprite sprite = itemFact.GenerateSprite(item.State, item.xLocation, item.yLocation);
                GameObject gameObject = new Item(sprite.Position, (ItemSprite)sprite);
                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
            
            coinBlockList = level.LoadBlocks();
            blockFact = new BlockSpriteFactory();
            foreach (CoinMap.BlockData block in coinBlockList)
            {
                GameObject gameObject;
                Sprite sprite = blockFact.GenerateSprite(block.State, block.xLocation, block.yLocation);
                if (block.State == 0)
                {
                    gameObject = new BrickBlockObject(sprite.Position, (BrickBlock)sprite, false, 0, null);
                }
                else
                {
                    gameObject = new BlockObject(sprite.Position, (BlockSprite)sprite);
                }
                layers[0].objs.Add(gameObject);
                Objects.Add(gameObject);
                grid.Add(gameObject);
            }
        }
        public void Pause()
        {
            isPaused = !isPaused;
        }
    }
}
