﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.Enemy
{
    public class Piranha : GameObject
    {
        public int initialY;
        public Piranha(Vector2 position, EnemySprite sprite)
            : base(position, sprite)
        {
            this.Sprite = sprite;
            this.Position = new Vector2(position.X+8,position.Y-8);
            Sprite.whatAmI = Sprite.id.Piranha;
            initialY = (int)position.Y - 8;
        }

        public void Initialize()
        {
            this.Velocity = new Vector2(0, -5);
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            Sprite.Update(gameTime, graphics);
            if (this.Position.Y <= (initialY-30))
            {
                this.Velocity = new Vector2(0, 5);
            }
            else if (this.Position.Y >= initialY)
            {
                this.Velocity = new Vector2(0, -5);
            }
            Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
            
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            Sprite.Draw(spriteBatch);
        }
    }
}
