﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.States.Actions;

namespace wildcats_sprint1.Objects.Enemy.States.Actions
{
    public abstract class EnemyActionState : IEnemyActionState
    {
        protected EnemyActionStateMachine enemyActionStateMachine;
        protected IEnemyActionState previousActionState;
        protected Kinematics previousKinematics;

        public Enemy Enemy { get { return enemyActionStateMachine.Enemy; } }

        protected IEnemyActionState CurrentActionState { get { return Enemy.CurrentActionState; } set { Enemy.CurrentActionState = value; } }
        public IEnemyActionState PreviousActionState { get { return previousActionState; } }

        public Kinematics PreviousKinematics
        {
            get { return previousKinematics; }
            set { previousKinematics = value; }
        }
        

        public EnemyActionState(EnemyActionStateMachine marioActionStateMachine)
        {
            this.enemyActionStateMachine = marioActionStateMachine;
        }

        public abstract void Enter(IEnemyActionState previousActionState);
        public abstract void Exit();
        public abstract void changeToFalling();
        public abstract void changeToDead();
        public abstract void changeToMoving();
    }
}
