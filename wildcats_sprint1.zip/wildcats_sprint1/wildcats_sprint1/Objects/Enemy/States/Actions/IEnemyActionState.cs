﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Objects.Enemy.States.Actions
{
    public interface IEnemyActionState
    {
        Enemy Enemy { get; }
        IEnemyActionState PreviousActionState { get; }

        void Enter(IEnemyActionState previousActionState);
        void Exit();
        void changeToFalling();
        void changeToDead();
        void changeToMoving();
    }
}
