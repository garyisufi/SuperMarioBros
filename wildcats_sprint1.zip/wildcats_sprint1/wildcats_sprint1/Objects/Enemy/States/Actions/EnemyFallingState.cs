﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.States.Actions;

namespace wildcats_sprint1.Objects.Enemy.States.Actions
{
    public class EnemyFallingState : EnemyActionState
    {
        const float Acceleration = 50.0f;
        const float Deacceleration = 25.0f;

        public EnemyFallingState(EnemyActionStateMachine enemyActionStateMachine)
            : base(enemyActionStateMachine)
        {

        }
        public override void Enter(IEnemyActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Enemy.AABB.Velocity, Enemy.AABB.Acceleration);

            AABB aabb = Enemy.AABB;
            eDirection Direction = Enemy.Direction;
            Enemy.Sprite = new EnemySprite(Game1.Game.Content.Load<Texture2D>("Characters/Enemies/GoombaSpriteNoBackground"), new Point(16, 16), new Vector2(500, 500), 2, true);
            Enemy.Direction = Direction;
            Enemy.Sprite.MillisecondsPerFrame = 250;

            Enemy.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Enemy.Sprite.FrameSize.Y), new Vector2(aabb.Velocity.X, 1.0f), new Vector2((Enemy.Direction == eDirection.Right) ? Acceleration : -Acceleration, 0.0f));

            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            enemyActionStateMachine.OnStateChanged(this, args);
        }
        public override void Exit() { }
        public override void changeToDead()
        {
            Exit();
            //Enemy.Position = new Vector2(-12345, -1234);
            //Enemy.Sprite.AABB = new AABB(new Rectangle());
            enemyActionStateMachine.StateEnemyDead.Enter(this);
        }
        public override void changeToMoving()
        {
            Exit();
            enemyActionStateMachine.StateEnemyMoving.Enter(this);
        }

        public override void changeToFalling()
        {

        }
    }
}
