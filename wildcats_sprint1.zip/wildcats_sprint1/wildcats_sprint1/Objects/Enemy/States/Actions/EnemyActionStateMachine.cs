﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Objects.Enemy.States.Actions
{
    public class ActionStateChangedEventArgs : EventArgs
    {
        private IEnemyActionState previousActionState;

        public ActionStateChangedEventArgs(IEnemyActionState previousActionState)
        {
            this.previousActionState = previousActionState;
        }
        public IEnemyActionState PreviousActionState
        {
            get { return previousActionState; }
        }
    }

    public delegate void ActionStateChangedEventHandler(object sender, ActionStateChangedEventArgs args);
    public class EnemyActionStateMachine
    {
        Enemy enemy;
        internal Enemy Enemy
        {
            get { return enemy; }
        }

        private IEnemyActionState stateEnemyMoving;
        private IEnemyActionState stateEnemyFalling;
        private IEnemyActionState stateEnemyDead;

        internal IEnemyActionState StateEnemyMoving
        {
            get { return stateEnemyMoving; }
        }
        internal IEnemyActionState StateEnemyFalling
        {
            get { return stateEnemyFalling; }
        }
        internal IEnemyActionState StateEnemyDead
        {
            get { return stateEnemyDead; }
        }
        private IEnemyActionState currentState;
        internal IEnemyActionState CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }
        public EnemyActionStateMachine(Enemy enemy)
        {
            this.enemy = enemy;

            stateEnemyMoving = new EnemyMovingState(this);
            stateEnemyDead = new EnemyDeadState(this);
            stateEnemyFalling = new EnemyFallingState(this);
        }

        public event ActionStateChangedEventHandler StateChanged;

        internal virtual void OnStateChanged(object sender, ActionStateChangedEventArgs args)
        {
            if (StateChanged != null)
                StateChanged(sender, args);
        }
    }
}
