﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Objects.Enemy.States.Actions;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.Objects.Enemy
{
    public class Enemy : GameObject
    {
        private EnemyActionStateMachine actionStateMachine;
        internal EnemyActionStateMachine ActionStateMachine
        {
            get { return actionStateMachine; }
        }
        
        internal IEnemyActionState CurrentActionState
        {
            get { return ActionStateMachine.CurrentState; }
            set { ActionStateMachine.CurrentState = value; }
        }
        
        public static bool displayBorder { get; set; }
        protected bool isDead { get; set; }


        public Enemy(Vector2 position, EnemySprite sprite)
            : base(position, sprite)
        {
            actionStateMachine = new EnemyActionStateMachine(this);

            Velocity = new Vector2(-20, 0);
            displayBorder = false;
            isDead = false;
            Initialize();
        }

        public void Initialize()
        {
            Sprite.Direction = eDirection.Right;
            CurrentActionState = actionStateMachine.StateEnemyMoving;
            collider = new EnemyCollider(this);
            detector = new EnemyDetector(this);
            CurrentActionState.Enter(null);
            
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if ((int)Velocity.Y==0)
            {
                Grid gameGrid = Game1.Game.grid;
                List<GameObject> objects = gameGrid.PossibleCollisions((int)Sprite.Position.X, (int)Sprite.Position.Y);
                Sprite.Position += new Vector2(0, 8);
                bool isBlockBelow = false;
                foreach (GameObject obj in objects)
                {
                    isBlockBelow = isBlockBelow || detector.DetectCollision(obj, gameTime);
                }
                if (!isBlockBelow)
                {
                    
                    changeToFalling();

                }
                Sprite.Position -= new Vector2(0, 8);
            }
            Sprite.Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Sprite.Update(gameTime, graphics);
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            Sprite.DrawAABB = Mario.displayBorder;
            Sprite.Draw(spriteBatch);
        }
        public void changeToMoving()
        {
            Velocity = new Vector2(Velocity.X, 0);
        }
        public void changeToDead()
        {
            Position = new Vector2(-12345, -1234);
            
        }
        public void changeToFalling()
        {
            Velocity = new Vector2(Velocity.X, 70);
        }
    }
}
