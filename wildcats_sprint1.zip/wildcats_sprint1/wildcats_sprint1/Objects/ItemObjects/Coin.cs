﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class Coin : Item
    {
        bool isBlockCoin;
        public Coin(Vector2 position, ItemSprite sprite, bool blockCoin)
            : base(position, sprite)
        {
            Sprite.whatAmI = Sprite.id.Coin;
            isBlockCoin = blockCoin;

        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            Sprite.Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Sprite.Update(gameTime, graphics);
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            Sprite.Draw(spriteBatch);
        }
    }
}
