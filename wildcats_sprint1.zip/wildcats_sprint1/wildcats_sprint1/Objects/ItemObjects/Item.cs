﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class Item : GameObject
    {
        public bool isRevealed;
        public bool isFullyRevealed;
        protected int howRevealed;
        public Item(Vector2 position, Sprite sprite)
            : base(position, sprite)
        {
            collider = new ItemCollider(this);
            detector = new ItemDetector(this);
        }
        public void PickUp()
        {
            Position = new Vector2(-12345, -1234);
        }
        public void ChangeDirection()
        {
            Velocity = new Vector2(Velocity.X * -1, Velocity.Y);
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (isFullyRevealed)
            {

                    Grid gameGrid = Game1.Game.grid;
                    List<GameObject> objects = gameGrid.PossibleCollisions((int)Sprite.Position.X, (int)Sprite.Position.Y);
                    Sprite.Position += new Vector2(0, 8);
                    bool isBlockBelow = false;
                    foreach (GameObject obj in objects)
                    {
                        isBlockBelow = isBlockBelow || detector.DetectCollision(obj, gameTime);
                    }
                    if (!isBlockBelow)
                    {
                        Velocity = new Vector2(Velocity.X, 60);
                    }
                    Sprite.Position -= new Vector2(0, 8);
                
            
                Sprite.Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
                Console.WriteLine(Velocity);
                Sprite.Update(gameTime, graphics);
            }

            else
            {
                if(isRevealed)
                {
                    Position = new Vector2(Position.X, Position.Y - 1);
                    howRevealed++;
                    if(howRevealed == 19 )
                    {
                        isFullyRevealed = true;
                    }
                }
            }
        }
        public virtual void SetStartDirection()
        {

        }
    }
}
