﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class Star : Item
    {
        public static bool displayBorder { get; set; }
        protected new Vector2 Velocity;

        public Star(Vector2 position, ItemSprite sprite)
            : base(position, sprite)
        {
            Sprite.whatAmI = Sprite.id.Star;
            Velocity = new Vector2(50, 50);
            Sprite.Acceleration = new Vector2(0, 50);
            detector = new ItemDetector(this);
            detector.Collidable = false;

        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (isFullyRevealed)
            {

                if(Sprite.Position.Y>204)
                {
                    Velocity = new Vector2(Velocity.X, -50);
                }
                Velocity += Sprite.Acceleration * (float)gameTime.ElapsedGameTime.TotalSeconds;
                Sprite.Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
                Sprite.Update(gameTime, graphics);
            }

            else
            {
                if (isRevealed)
                {
                    Position = new Vector2(Position.X, Position.Y - 1);
                    howRevealed++;
                    if (howRevealed == 19)
                    {
                        isFullyRevealed = true;
                    }
                }
            }

        }

        }
}
