﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class Fireball : Item
    {
        public Fireball(Vector2 position, Sprite sprite)
            : base(position, sprite)
        {
            SetStartDirection();
            Sprite.whatAmI = Sprite.id.Fireball;

        }
        public override void SetStartDirection()
        {
            if (Game1.Game.mario.Direction == eDirection.Right)
            {
                Velocity = new Vector2(40, 0);
            } else
            {
                Velocity = new Vector2(-40, 0);
            }
        }
    }
}
