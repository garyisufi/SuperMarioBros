﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class GreenMushroom : Item
    {

        public GreenMushroom(Vector2 position, ItemSprite sprite)
            : base(position, sprite)
        {
            Velocity = new Vector2(-40, 0);
            Sprite.whatAmI = Sprite.id.GreenMushroom;

        }

  
        public override void SetStartDirection()
        {
            if(Game1.Game.mario.Direction == eDirection.Left)
            {
                Velocity = new Vector2(40, 0);
            }
        }
    }
}
