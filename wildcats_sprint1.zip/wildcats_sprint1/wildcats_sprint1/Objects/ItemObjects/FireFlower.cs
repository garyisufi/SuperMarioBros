﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.ItemObjects
{
    public class FireFlower : Item
    {
  
        public FireFlower(Vector2 position, ItemSprite sprite)
            : base(position, sprite)
        {
            Sprite.whatAmI = Sprite.id.FireFlower;

        }

    }
}
