﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.Enemies
{
    public class Enemy : GameObject
    {
        public Enemy(Vector2 position, Vector2 velocity, Sprite sprite)
            : base(position, velocity, sprite)
        {


            Initialize();

        }

        public Enemy(Vector2 position, Sprite sprite)
            : base(position, sprite)
        {

            Initialize();
        }

        public void Initialize()
        {
            Sprite.Direction = eDirection.Right;
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            {
                // Move the sprite by acceleration, scaled by elapsed time.
                Sprite.Velocity += Sprite.Acceleration * (float)gameTime.ElapsedGameTime.TotalSeconds;
                Sprite.Position += Sprite.Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
                //                sprite.Location = Vector2.Clamp(sprite.Location, new Vector2(0, 0), new Vector2(Scene.Stage.Game.GraphicsDevice.Viewport.Width - sprite.AABB.Width, (Scene.Stage.Game.GraphicsDevice.Viewport.Height - 33) - sprite.AABB.Height));
            }

            Sprite.Update(gameTime, graphics);
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            // SpriteSheet has sprite definitions facing RIGHT
            if (Direction == eDirection.Left)
                Sprite.SpriteEffects = SpriteEffects.FlipHorizontally;
            else
                Sprite.SpriteEffects = SpriteEffects.None;

            Sprite.Draw(spriteBatch);
        }
        
        
        
    }
}
