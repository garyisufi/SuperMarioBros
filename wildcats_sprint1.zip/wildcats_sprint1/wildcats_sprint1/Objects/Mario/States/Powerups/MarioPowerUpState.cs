﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.States.Powerups
{
    public abstract class MarioPowerUpState : IMarioPowerUpState
    {
        protected MarioPowerUpStateMachine marioPowerUpStateMachine;
        protected IMarioPowerUpState previousPowerUpState;
        protected Mario Mario { get { return marioPowerUpStateMachine.Mario; } }
        protected IMarioActionState CurrentActionState { get { return Mario.CurrentActionState; } set { Mario.CurrentActionState = value; } }
        protected IMarioPowerUpState CurrentPowerUpState { get { return Mario.CurrentPowerUpState; } set { Mario.CurrentPowerUpState = value; } }
        IMarioPowerUpState IMarioPowerUpState.PreviousPowerUpState { get { return previousPowerUpState; } }
        

        public MarioPowerUpState(MarioPowerUpStateMachine marioPowerUpStateMachine)
        {
            this.marioPowerUpStateMachine = marioPowerUpStateMachine;
        }

        public abstract void Enter(IMarioPowerUpState previousPowerUpState);

        public abstract void Exit();

        public abstract void Update(GameTime gameTime, GraphicsDeviceManager graphics);

        public abstract void TakeDamage();
        public abstract void ThrowFireball();
    }
}
