﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;

namespace wildcats_sprint1.States.Powerups
{
    public class MarioStarState : MarioPowerUpState
    {
        public MarioStarState(MarioPowerUpStateMachine marioPowerUpStateMachine)
            : base(marioPowerUpStateMachine)
        {
        }

        public override void Enter(IMarioPowerUpState previousPowerUpState)
        {
            CurrentPowerUpState = this;
            this.previousPowerUpState = previousPowerUpState;
            Vector2 velocity = marioPowerUpStateMachine.Mario.AABB.Velocity;

            Mario.CurrentActionState.Enter(Mario.CurrentActionState.PreviousActionState);
            Mario.AABB.Velocity = velocity;

            PowerUpStateChangedEventArgs args = new PowerUpStateChangedEventArgs(previousPowerUpState);
            marioPowerUpStateMachine.OnStateChanged(this, args);
        }
        public override void Exit()
        {
            Mario.CurrentPowerUpState = previousPowerUpState;
            Mario.CurrentPowerUpState.Enter(this);
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
        }
        public override void TakeDamage()
        {

        }

        public override void ThrowFireball()
        {
            
        }
    }
}
