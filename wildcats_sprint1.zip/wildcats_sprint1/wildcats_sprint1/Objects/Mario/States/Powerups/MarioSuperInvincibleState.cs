﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;

namespace wildcats_sprint1.States.Powerups
{
    public class MarioSuperInvincibleState : MarioPowerUpState
    {
        private int _timer;

        public MarioSuperInvincibleState(MarioPowerUpStateMachine marioPowerUpStateMachine)
            : base(marioPowerUpStateMachine)
        {
        }

        public override void Enter(IMarioPowerUpState previousPowerUpState)
        {
            CurrentPowerUpState = this;
            this.previousPowerUpState = previousPowerUpState;
            Vector2 velocity = Mario.AABB.Velocity;
            Vector2 acceleration = Mario.AABB.Acceleration;

            CurrentActionState.Enter(Mario.CurrentActionState.PreviousActionState);
            Mario.AABB.Velocity = velocity;
            Mario.AABB.Acceleration = acceleration;

            PowerUpStateChangedEventArgs args = new PowerUpStateChangedEventArgs(previousPowerUpState);
            marioPowerUpStateMachine.OnStateChanged(this, args);

            _timer = 6000;
        }
        public override void Exit()
        {
            Mario.CurrentPowerUpState = previousPowerUpState;
            Mario.CurrentPowerUpState.Enter(this);
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            _timer -= gameTime.ElapsedGameTime.Milliseconds;
            if (_timer <= 0)
                Exit();
        }
        public override void TakeDamage()
        {
        }

        public override void ThrowFireball()
        {
        }
    }
}
