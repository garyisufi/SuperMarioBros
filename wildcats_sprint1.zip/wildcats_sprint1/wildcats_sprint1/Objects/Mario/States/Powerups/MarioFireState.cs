﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;

namespace wildcats_sprint1.States.Powerups
{
    public class MarioFireState : MarioPowerUpState
    {
        int timer;
        public MarioFireState(MarioPowerUpStateMachine marioPowerUpStateMachine)
            : base(marioPowerUpStateMachine)
        {
        }

        public override void Enter(IMarioPowerUpState previousPowerUpState)
        {
            CurrentPowerUpState = this;
            Mario.invincible = false;
            Mario.detector.Collidable = true;
            timer = 1000;
            this.previousPowerUpState = previousPowerUpState;
            Vector2 velocity = Mario.AABB.Velocity;
            Vector2 acceleration = Mario.AABB.Acceleration;

            CurrentActionState.Enter(Mario.CurrentActionState.PreviousActionState);
            Mario.AABB.Velocity = velocity;
            Mario.AABB.Acceleration = acceleration;

            PowerUpStateChangedEventArgs args = new PowerUpStateChangedEventArgs(previousPowerUpState);
            marioPowerUpStateMachine.OnStateChanged(this, args);
        }
        public override void Exit() {
            Game1.Game.mario.isFire = false;
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            timer -= gameTime.ElapsedGameTime.Milliseconds;
            if (timer < 0)
            {
                Mario.detector.Collidable = true;
                Mario.invincible = false;
                Mario.deathReset = false;
            }
        }
        public override void TakeDamage()
        {
            CurrentPowerUpState.Exit();
            if (previousPowerUpState == Mario.PowerUpStateMachine.StateMarioStandard)
            {
                marioPowerUpStateMachine.StateMarioStandard.Enter(this);
            } else
            {
                marioPowerUpStateMachine.StateMarioSuper.Enter(this);
            }
            
            Mario.PowerUpStateMachine.CurrentState = previousPowerUpState;
        }
        public override void ThrowFireball()
        {
        }
    }
}
