﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.States.Powerups;

namespace wildcats_sprint1.States
{
    public class PowerUpStateChangedEventArgs : EventArgs
    {
        private IMarioPowerUpState previousPowerUpState;

        public PowerUpStateChangedEventArgs(IMarioPowerUpState previousPowerUpState)
        {
            this.previousPowerUpState = previousPowerUpState;
        }

        public IMarioPowerUpState PreviousPowerUpState
        {
            get { return previousPowerUpState; }
        }
    }

    public delegate void PowerUpStateChangedEventHandler(object sender, PowerUpStateChangedEventArgs args);

    public class MarioPowerUpStateMachine
    {
        private Mario mario;

        internal Mario Mario
        {
            get { return mario; }
            //set { mario = value; }
        }

        private IMarioPowerUpState stateMarioStandard;
        private IMarioPowerUpState stateMarioSuper;
        private IMarioPowerUpState stateMarioFire;
        private IMarioPowerUpState stateMarioInvincible;
        private IMarioPowerUpState stateMarioSuperInvincible;

        internal IMarioPowerUpState StateMarioStandard
        {
            get { return stateMarioStandard; }
        }

        internal IMarioPowerUpState StateMarioSuper
        {
            get { return stateMarioSuper; }
        }

        internal IMarioPowerUpState StateMarioFire
        {
            get { return stateMarioFire; }
        }

        internal IMarioPowerUpState StateMarioInvincible
        {
            get { return stateMarioInvincible; }
        }

        internal IMarioPowerUpState StateMarioSuperInvincible
        {
            get { return stateMarioSuperInvincible; }
        }

        private IMarioPowerUpState currentState;

        internal IMarioPowerUpState CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }
        public MarioPowerUpStateMachine(Mario mario)
        {
            this.mario = mario;

            stateMarioStandard = new MarioStandardState(this);
            stateMarioSuper = new MarioSuperState(this);
            stateMarioFire = new MarioFireState(this);
            stateMarioInvincible = new MarioInvincibleState(this);
            stateMarioSuperInvincible = new MarioSuperInvincibleState(this);
        }

        public event PowerUpStateChangedEventHandler StateChanged;

        internal virtual void OnStateChanged(object sender, PowerUpStateChangedEventArgs args)
        {
            if (StateChanged != null)
                StateChanged(sender, args);
        }
    }
}
