﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Interfaces
{
    public interface IMarioPowerUpState
    {
        IMarioPowerUpState PreviousPowerUpState { get; }

        void Enter(IMarioPowerUpState previousPowerUpState);
        void Exit();
        void Update(GameTime gameTime, GraphicsDeviceManager graphics);
        void TakeDamage();
        void ThrowFireball();
    }
}
