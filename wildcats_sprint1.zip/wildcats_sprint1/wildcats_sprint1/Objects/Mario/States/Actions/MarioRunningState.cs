﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioRunningState : MarioActionState
    {
        const float Acceleration = 75.0f;
        const float Deacceleration = 35.0f;

        public MarioRunningState(MarioActionStateMachine marioActionStateMachine)
            : base(marioActionStateMachine)
        {
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);

            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.Direction = Direction;
            Mario.Sprite.MillisecondsPerFrame = 100;
            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), new Vector2(aabb.Velocity.X, 0.0f), new Vector2((Mario.Direction == eDirection.Right) ? Acceleration : -Acceleration, 0.0f));

            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }

        public override void Exit() { }
        public override void ChangeToStanding()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioStanding.Enter(this);
        }
        public override void ChangeToCrouching() { }
        public override void ChangeToLeftFacing()
        {
            if (Mario.Direction == eDirection.Right)
                WalkingTransition();
        }
        public override void ChangeToRightFacing()
        {
            if (Mario.Direction == eDirection.Left)
                WalkingTransition();
        }
        public override void WalkingTransition()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioWalking.Enter(this);
        }

        public override void ChangeToRunning() { }
        public override void ChangeToJumping()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioJumping.Enter(this);
        }

        public override void ChangeToFalling()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioFalling.Enter(previousActionState);
        }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { }

        public override void StopChangeToLeftFacing()
        {
            Mario.Sprite.AABB.Acceleration = new Vector2((Mario.Direction == eDirection.Left) ? Deacceleration : -Deacceleration, Mario.Sprite.AABB.Acceleration.Y);
        }
        public override void StopChangeToRightFacing()
        {
            Mario.Sprite.AABB.Acceleration = new Vector2((Mario.Direction == eDirection.Right) ? -Deacceleration : Deacceleration, Mario.Sprite.AABB.Acceleration.Y);
        }
        public override void StopChangeToWalking() { }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (Math.Abs(Mario.AABB.Velocity.X) <= 25.0F && Math.Abs(Mario.AABB.Acceleration.X) == Deacceleration)
            {
                WalkingTransition();
                CurrentActionState.StopChangeToWalking();
            }

            
        }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            if (Mario.Direction == eDirection.Right)
                return Vector2.Clamp(velocity, new Vector2(0, 0), new Vector2(150, 0));
            else
                return Vector2.Clamp(velocity, new Vector2(-150, 0), new Vector2(0, 0));
        }
    }
}
