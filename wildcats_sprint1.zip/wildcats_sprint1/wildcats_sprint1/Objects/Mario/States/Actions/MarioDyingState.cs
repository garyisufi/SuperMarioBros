﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioDyingState : MarioActionState
    {
        Vector2 iniPos;
        private int timer;
        public MarioDyingState(MarioActionStateMachine marioActionStateMachine)
            : base(marioActionStateMachine)
        {
            iniPos = Mario.Position;
            
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            timer = 3000;
            Mario.invincible = true;
            Mario.detector.Collidable = false;
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);
            
            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.Direction = Direction;

            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), Vector2.Zero, new Vector2(0.0f, -100.0f));
            Mario.detector.Collidable = false;
            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }
        public override void Exit() {
            Mario.detector.Collidable = true;
            Mario.invincible = false;
            Mario.deathReset = true;
        }
        public override void ChangeToStanding()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioStanding.Enter(this);
            Mario.CurrentPowerUpState = Mario.PowerUpStateMachine.StateMarioStandard;
            Mario.CurrentActionState = Mario.ActionStateMachine.StateMarioStanding;
        }
        
        public override void ChangeToCrouching() { }
        public override void ChangeToLeftFacing() { }
        public override void ChangeToRightFacing() { }
        public override void WalkingTransition() { }

        public override void ChangeToRunning() { }
        public override void ChangeToJumping() { }

        public override void ChangeToFalling() { }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { }
        public override void StopChangeToLeftFacing() { }
        public override void StopChangeToRightFacing() { }
        public override void StopChangeToWalking() { }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            Mario.detector.Collidable = false;
            if ((Mario.Sprite.Velocity.Y == -100.0f) ||
                Mario.Sprite.AABB.Position.Y < 0.0f)
            {
                Mario.Sprite.Acceleration *= new Vector2(0.0f, -1.0f);
            }


            if (Mario.Sprite.AABB.Position.Y < 0.0f)
            {
                Mario.Sprite.AABB.Y = 0.0f;
            }
            timer -= gameTime.ElapsedGameTime.Milliseconds;
            if (timer < 0)
            {
                //Game1.Game.ResetCommand();
                Mario.Sprite.Velocity = Vector2.Zero;
                Mario.Sprite.Acceleration = Vector2.Zero;
                Mario.Position = iniPos;
                //Mario.Position = new Vector2(0, Mario.Position.Y);
                CurrentActionState.Exit();
                marioActionStateMachine.StateMarioStanding.Enter(marioActionStateMachine.StateMarioStanding);

            }

          }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            if (Mario.Sprite.Acceleration.Y < 0.0f)    
                return Vector2.Clamp(velocity, new Vector2(0, -100), new Vector2(0, 0));
            else
                return Vector2.Clamp(velocity, new Vector2(0, 0), new Vector2(0, 100));
        }
    }
}
