﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioWalkingState : MarioActionState
    {
        const float Acceleration = 50.0f;
        const float Deacceleration = 25.0f;

        public MarioWalkingState(MarioActionStateMachine marioActionStateMachine)
            : base(marioActionStateMachine)
        {
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);

            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.Direction = Direction;
            Mario.Sprite.MillisecondsPerFrame = 250;

            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), new Vector2(aabb.Velocity.X, 0.0f), new Vector2((Mario.Direction == eDirection.Right) ? Acceleration : -Acceleration, 0.0f));

            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }

        public override void Exit() { }
        public override void ChangeToStanding()
        {
            Exit();
            marioActionStateMachine.StateMarioStanding.Enter(this);
        }
        public override void ChangeToCrouching()
        {
        }
        public override void ChangeToLeftFacing()
        {
            if (Mario.Direction == eDirection.Right)
                ChangeToStanding();
            else
                ChangeToRunning();
        }
        public override void ChangeToRightFacing()
        {
            if (Mario.Direction == eDirection.Left)
                ChangeToStanding();
            else
                ChangeToRunning();
        }
        public override void WalkingTransition()
        {

        }

        public override void ChangeToRunning()
        {
            Exit();
            marioActionStateMachine.StateMarioRunning.Enter(this);
        }
        public override void ChangeToJumping()
        {
            Exit();
            marioActionStateMachine.StateMarioJumping.Enter(this);
        }

        public override void ChangeToFalling()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioFalling.Enter(previousActionState);
        }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { }
        public override void StopChangeToLeftFacing()
        {
            ChangeToStanding();
        }
        public override void StopChangeToRightFacing()
        {
            ChangeToStanding();
        }

        public override void StopChangeToWalking()
        {
            Mario.Sprite.AABB.Acceleration = new Vector2((Mario.Direction == eDirection.Right) ? -Deacceleration : Deacceleration, Mario.Sprite.AABB.Acceleration.Y);
        }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (Math.Abs(Mario.AABB.Velocity.X) <= 5.0F && Math.Abs(Mario.AABB.Acceleration.X) == Deacceleration)
                ChangeToStanding();

        }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            if (Mario.Direction == eDirection.Right)
                return Vector2.Clamp(velocity, new Vector2(0, 0), new Vector2(50, 0));
            else
                return Vector2.Clamp(velocity, new Vector2(-50, 0), new Vector2(0, 0));
        }
    }
}
