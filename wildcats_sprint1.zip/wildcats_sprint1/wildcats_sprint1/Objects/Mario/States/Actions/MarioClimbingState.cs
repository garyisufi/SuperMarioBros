﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Objects.Mario.States.Actions
{
    class MarioClimbingState
    {
    }
}
