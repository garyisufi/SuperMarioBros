﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioJumpingState : MarioActionState
    {
        const float Gravity = 300.0f;
        const float VerticalAcceleration = 225.0f;
        const float HorizontalAcceleration = 75.0f;
        const float Deacceleration = 25.0f;

        public MarioJumpingState(MarioActionStateMachine marioActionStateMachine)
            : base(marioActionStateMachine)
        {
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);

            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.Direction = Direction;

            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), new Vector2(aabb.Velocity.X, -VerticalAcceleration), new Vector2(0.0f, Gravity));

            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }
        public override void Exit()
        {
            //           previousActionState.Enter(this);
        }
        public override void ChangeToStanding()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioStanding.Enter(this);
        }
        public override void ChangeToCrouching()
        {
        }

        public override void ChangeToLeftFacing()
        {
            if (Mario.Direction == eDirection.Right)
            {
                Mario.Direction = eDirection.Left;
                Mario.Sprite.AABB.Velocity = new Vector2(0.0f, Mario.Sprite.AABB.Velocity.Y);
            }
            Mario.Sprite.AABB.Acceleration = new Vector2(-HorizontalAcceleration, Mario.Sprite.AABB.Acceleration.Y);
        }

        public override void ChangeToRightFacing()
        {
            if (Mario.Direction == eDirection.Left)
            {
                Mario.Direction = eDirection.Right;
                Mario.Sprite.AABB.Velocity = new Vector2(0.0f, Mario.Sprite.AABB.Velocity.Y);
            }
            Mario.Sprite.AABB.Acceleration = new Vector2(HorizontalAcceleration, Mario.Sprite.AABB.Acceleration.Y);
        }
        public override void WalkingTransition() { }

        public override void ChangeToRunning() { }
        public override void ChangeToJumping() { }

        public override void ChangeToFalling()
        {
            if (Mario.Sprite.Velocity.Y > 0)
            {
                CurrentActionState.Exit();
                marioActionStateMachine.StateMarioFalling.Enter(previousActionState);
            }
            else
            {
                Mario.Sprite.Velocity *= .70f;
            }
        }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { }

        public override void StopChangeToLeftFacing()
        {
            Mario.Sprite.AABB.Acceleration = new Vector2(0.0f, Mario.Sprite.AABB.Acceleration.Y);
            if (previousActionState is MarioRunningState || previousActionState is MarioWalkingState)
                previousActionState = marioActionStateMachine.StateMarioStanding;
        }

        public override void StopChangeToRightFacing()
        {
            Mario.Sprite.AABB.Acceleration = new Vector2(0.0f, Mario.Sprite.AABB.Acceleration.Y);
            if (previousActionState is MarioRunningState || previousActionState is MarioWalkingState)
                previousActionState = marioActionStateMachine.StateMarioStanding;
        }
        public override void StopChangeToWalking() { }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { ChangeToFalling(); }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (Mario.AABB.Velocity.Y >= 0.0f)
                ChangeToFalling();
     
        }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            return Vector2.Clamp(velocity, new Vector2((Mario.Direction == eDirection.Left) ? -100 : 0, velocity.Y), new Vector2((Mario.Direction == eDirection.Left) ? 0 : 100, velocity.Y));
        }
    }
}
