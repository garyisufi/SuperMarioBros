﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.States.Actions;

namespace wildcats_sprint1.States
{
    public class ActionStateChangedEventArgs : EventArgs
    {
        private IMarioActionState previousActionState;

        public ActionStateChangedEventArgs(IMarioActionState previousActionState)
        {
            this.previousActionState = previousActionState;
        }
        public IMarioActionState PreviousActionState
        {
            get { return previousActionState; }
        }
    }

    public delegate void ActionStateChangedEventHandler(object sender, ActionStateChangedEventArgs args);

    public class MarioActionStateMachine
    {
        private Mario mario;

        internal Mario Mario
        {
            get { return mario; }
            //set { mario = value; }
        }

        private IMarioActionState stateMarioIdling;
        private IMarioActionState stateMarioCrouching;
        private IMarioActionState stateMarioJumping;
        private IMarioActionState stateMarioFalling;
        private IMarioActionState stateMarioBouncing;
        private IMarioActionState stateMarioWalking;
        private IMarioActionState stateMarioRunning;
        private IMarioActionState stateMarioDying;

        internal IMarioActionState StateMarioStanding
        {
            get { return stateMarioIdling; }
        }

        internal IMarioActionState StateMarioCrouching
        {
            get { return stateMarioCrouching; }
        }

        internal IMarioActionState StateMarioJumping
        {
            get { return stateMarioJumping; }
        }

        internal IMarioActionState StateMarioFalling
        {
            get { return stateMarioFalling; }
        }

        internal IMarioActionState StateMarioBouncing
        {
            get { return stateMarioBouncing; }
        }

        internal IMarioActionState StateMarioWalking
        {
            get { return stateMarioWalking; }
        }

        internal IMarioActionState StateMarioRunning
        {
            get { return stateMarioRunning; }
        }

        internal IMarioActionState StateMarioDying
        {
            get { return stateMarioDying; }
        }

        private IMarioActionState currentState;

        internal IMarioActionState CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }
        public MarioActionStateMachine(Mario mario)
        {
            this.mario = mario;

            stateMarioIdling = new MarioStandingState(this);
            stateMarioCrouching = new MarioCrouchingState(this);
            stateMarioJumping = new MarioJumpingState(this);
            stateMarioFalling = new MarioFallingState(this);
            stateMarioBouncing = new MarioBouncingState(this);
            stateMarioWalking = new MarioWalkingState(this);
            stateMarioRunning = new MarioRunningState(this);
            stateMarioDying = new MarioDyingState(this);
        }

        public event ActionStateChangedEventHandler StateChanged;

        internal virtual void OnStateChanged(object sender, ActionStateChangedEventArgs args)
        {
            if (StateChanged != null)
                StateChanged(sender, args);
        }
    }
}
