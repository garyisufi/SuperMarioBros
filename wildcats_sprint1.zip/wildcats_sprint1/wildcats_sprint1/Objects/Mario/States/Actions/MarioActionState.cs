﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.States.Actions
{
    public abstract class MarioActionState : IMarioActionState
    {
        protected MarioActionStateMachine marioActionStateMachine;
        protected IMarioActionState previousActionState;
        protected Kinematics previousKinematics;

        public Mario Mario { get { return marioActionStateMachine.Mario; } }
        protected IMarioActionState CurrentActionState { get { return Mario.CurrentActionState; } set { Mario.CurrentActionState = value; } }
        public IMarioActionState PreviousActionState { get { return previousActionState; } }

        public Kinematics PreviousKinematics
        {
            get { return previousKinematics; }
            set { previousKinematics = value; }
        }

        protected IMarioPowerUpState CurrentPowerUpState { get { return Mario.CurrentPowerUpState; } }
        
        public MarioActionState(MarioActionStateMachine marioActionStateMachine)
        {
            this.marioActionStateMachine = marioActionStateMachine;
        }

        public abstract void Enter(IMarioActionState previousActionState);
        public abstract void Exit();
        public abstract void ChangeToStanding();
        public abstract void ChangeToCrouching();
        public abstract void ChangeToLeftFacing();
        public abstract void ChangeToRightFacing();
        public abstract void WalkingTransition();
        public abstract void ChangeToRunning();
        public abstract void ChangeToJumping();
        public abstract void ChangeToFalling();
        public abstract void BouncingTransition();

        public abstract void StopChangeToCrouch();
        public abstract void StopChangeToLeftFacing();
        public abstract void StopChangeToRightFacing();
        public abstract void StopChangeToWalking();
        public abstract void StopChangeToRunning();
        public abstract void StopChangeToJumping();

        public abstract void Update(GameTime gameTime, GraphicsDeviceManager graphics);

        public abstract Vector2 ClampVelocity(Vector2 velocity);
    }
}
