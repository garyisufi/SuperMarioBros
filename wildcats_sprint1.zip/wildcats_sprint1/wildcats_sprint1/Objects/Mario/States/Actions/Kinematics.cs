﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.States.Actions
{
    public class Kinematics
    {
        public Vector2 Velocity { get; set; }
        public Vector2 Acceleration { get; set; }

        public Kinematics(Vector2 velocity, Vector2 acceleration)
        {
            Velocity = velocity;
            Acceleration = acceleration;
        }

        public Kinematics(Kinematics kinematics)
        {
            Velocity = kinematics.Velocity;
            Acceleration = kinematics.Acceleration;
        }
    }
}
