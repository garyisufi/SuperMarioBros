﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Interfaces
{
    public interface IMarioActionState
    {
        Mario Mario { get; }
        IMarioActionState PreviousActionState { get; }

        void Enter(IMarioActionState previousActionState);
        void Exit();
        void ChangeToStanding();
        void ChangeToCrouching();
        void ChangeToLeftFacing();
        void ChangeToRightFacing();
        void WalkingTransition();
        void ChangeToRunning();
        void ChangeToJumping();
        void ChangeToFalling();
        void BouncingTransition();

        void StopChangeToCrouch();
        void StopChangeToLeftFacing();
        void StopChangeToRightFacing();
        void StopChangeToWalking();
        void StopChangeToRunning();
        void StopChangeToJumping();

        void Update(GameTime gameTime, GraphicsDeviceManager graphics);

        Vector2 ClampVelocity(Vector2 velocity);
    }
}
