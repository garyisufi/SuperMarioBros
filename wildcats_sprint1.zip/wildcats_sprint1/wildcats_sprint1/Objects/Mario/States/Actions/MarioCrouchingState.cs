﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioCrouchingState : MarioActionState
    {
        const float Gravity = 300.0f;
        const float VerticalAcceleration = 300.0f;
        const float HorizontalAcceleration = 75.0f;
        const float Deacceleration = 25.0f;
        public MarioCrouchingState(MarioActionStateMachine marioActionStateMachine)
            : base(marioActionStateMachine)
        {
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);

            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.Direction = Direction;
            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), new Vector2(aabb.Velocity.X, VerticalAcceleration), new Vector2(0, 0));

            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }

        public override void Exit() { }
        public override void ChangeToStanding()
        {
            CurrentActionState.Exit();
            marioActionStateMachine.StateMarioStanding.Enter(this);
        }
        public override void ChangeToCrouching() { }
        public override void ChangeToLeftFacing() { Mario.Direction = eDirection.Left; }
        public override void ChangeToRightFacing() { Mario.Direction = eDirection.Right; }
        public override void WalkingTransition() { }

        public override void ChangeToRunning() { }
        public override void ChangeToJumping()
        {
            ChangeToStanding();
        }

        public override void ChangeToFalling() { }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { ChangeToStanding(); }
        public override void StopChangeToLeftFacing() { }
        public override void StopChangeToRightFacing() { }
        public override void StopChangeToWalking() { }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { }


        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
        }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            return Vector2.Clamp(velocity, new Vector2((Mario.Direction == eDirection.Left) ? -100 : 0, 0), new Vector2((Mario.Direction == eDirection.Left) ? 0 : 100, 100));
        }
    }
}
