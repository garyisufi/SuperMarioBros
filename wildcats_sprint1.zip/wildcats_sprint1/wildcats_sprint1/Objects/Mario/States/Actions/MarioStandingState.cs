﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.SpriteClasses.Factories;

namespace wildcats_sprint1.States.Actions
{
    public class MarioStandingState : MarioActionState
    {
        public MarioStandingState(MarioActionStateMachine marioActionStateMachine)
             : base(marioActionStateMachine)
        {
        }

        public override void Enter(IMarioActionState previousActionState)
        {
            CurrentActionState = this;
            this.previousActionState = previousActionState;
            previousKinematics = new Kinematics(Mario.AABB.Velocity, Mario.AABB.Acceleration);

            AABB aabb = Mario.AABB;
            eDirection Direction = Mario.Direction;
            Mario.Sprite = Mario.SpriteFactory.GenerateSprite(MarioSpriteFactory.MarioSpriteType(this, CurrentPowerUpState), (int)Mario.Position.X, (int)Mario.Position.Y, Mario.Direction == eDirection.Left);
            Mario.AABB.Physics(new Vector2(aabb.X, aabb.Y + aabb.Height - Mario.Sprite.FrameSize.Y), Vector2.Zero, Vector2.Zero);
            Mario.Direction = Direction;


            ActionStateChangedEventArgs args = new ActionStateChangedEventArgs(previousActionState);
            marioActionStateMachine.OnStateChanged(this, args);
        }
        public override void Exit() { }
        public override void ChangeToStanding() { }
        public override void ChangeToCrouching()
        {
            Exit();
            marioActionStateMachine.StateMarioCrouching.Enter(this);
        }
        public override void ChangeToLeftFacing()
        {
            if (Mario.Direction == eDirection.Left)
                WalkingTransition();
            else
                Mario.Direction = eDirection.Left;
        }
        public override void ChangeToRightFacing()
        {
            if (Mario.Direction == eDirection.Right)
                WalkingTransition();
            else
                Mario.Direction = eDirection.Right;
        }

        public override void WalkingTransition()
        {
            Exit();
            marioActionStateMachine.StateMarioWalking.Enter(this);
        }

        public override void ChangeToRunning()
        {
            Exit();
            marioActionStateMachine.StateMarioRunning.Enter(this);
        }
        public override void ChangeToJumping()
        {
            Exit();
            marioActionStateMachine.StateMarioJumping.Enter(this);
        }
        public override void ChangeToFalling() { }
        public override void BouncingTransition() { }

        public override void StopChangeToCrouch() { }
        public override void StopChangeToLeftFacing() { }
        public override void StopChangeToRightFacing() { }
        public override void StopChangeToWalking() { }
        public override void StopChangeToRunning() { }
        public override void StopChangeToJumping() { }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
        }

        public override Vector2 ClampVelocity(Vector2 velocity)
        {
            return Vector2.Zero;
        }
    }
}
