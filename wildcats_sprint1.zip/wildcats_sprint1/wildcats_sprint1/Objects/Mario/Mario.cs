﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.Objects.Block;
using wildcats_sprint1.Score;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.SpriteClasses.Factories;
using wildcats_sprint1.States;
using wildcats_sprint1.States.Actions;
using wildcats_sprint1.States.Powerups;

namespace wildcats_sprint1.Objects
{
    public class Mario : GameObject
    {

        private MarioActionStateMachine actionStateMachine;
        private MarioPowerUpStateMachine powerupStateMachine;
        public static bool displayBorder { get; set; }
        public int leftBound { get; set; }

        public bool invincible = false;
        public bool deathReset = false;
        public bool isFire = false;
        public bool isVictory = false;
        private SoundEffect mySound;
        public int isDownPipe;

        internal MarioSpriteFactory SpriteFactory
        {
            get { return MarioSpriteFactory.DefaultMarioSpriteFactory; }
        }

        internal MarioActionStateMachine ActionStateMachine
        {
            get { return actionStateMachine; }
        }

        internal MarioPowerUpStateMachine PowerUpStateMachine
        {
            get { return powerupStateMachine; }
        }

        internal IMarioActionState CurrentActionState
        {
            get { return ActionStateMachine.CurrentState; }
            set { ActionStateMachine.CurrentState = value; }
        }

        internal IMarioPowerUpState CurrentPowerUpState
        {
            get { return PowerUpStateMachine.CurrentState; }
            set { PowerUpStateMachine.CurrentState = value; }
        }

        public Mario(Vector2 position, Vector2 velocity, Sprite sprite)
            : base(position, velocity, sprite)
        {
            actionStateMachine = new MarioActionStateMachine(this);
            powerupStateMachine = new MarioPowerUpStateMachine(this);
            displayBorder = false;
 
            Initialize();

        }

        public Mario(Vector2 position, Sprite sprite)
            : base(position, sprite)
        {
            actionStateMachine = new MarioActionStateMachine(this);
            powerupStateMachine = new MarioPowerUpStateMachine(this);

            displayBorder = false;
            Initialize();
        }

        public void Initialize()
        {
            Sprite.Direction = eDirection.Right;
            CurrentActionState = actionStateMachine.StateMarioStanding;
            CurrentActionState.Enter(null);
            leftBound = 0;
            CurrentPowerUpState = powerupStateMachine.StateMarioStandard;
            CurrentPowerUpState.Enter(null);
            detector = new MarioDetector(this);
            collider = new MarioCollider(this);
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {

            if (Position.X >= 3170 && !isVictory)
            {
                Scoreboard.getInstance().score += PointFromFlag();
                Scoreboard.getInstance().score += Scoreboard.getInstance().time * 2;
                detector.Collidable = false;
                VictoryTrigger();
            }
            else if (Position.X >= 3170 && isVictory && Position.X <= Game1.Game.EndLevel + 10)
            {
                if(Sprite.Position.Y + (Sprite.Height) < 224)
                {
                    Sprite.Position = new Vector2(Sprite.Position.X, Sprite.Position.Y + 1);
                }
                else
                {
                    Sprite.Position = new Vector2(Sprite.Position.X + 1, Sprite.Position.Y);

                }
            }
            else if (Position.X >= 3170 && isVictory)
            {
                detector.Collidable = true;
                Sprite.Position = new Vector2(Sprite.Position.X, Sprite.Position.Y - 10);


            }
            else
            {
                if (isDownPipe == 0)
                {
                    if (CurrentActionState is MarioWalkingState || CurrentActionState is MarioRunningState)
                    {
                        Grid gameGrid = Game1.Game.grid;
                        List<GameObject> objects = gameGrid.PossibleCollisions((int)Sprite.Position.X, (int)Sprite.Position.Y);
                        Sprite.Position += new Vector2(0, 8);
                        bool isBlockBelow = false;
                        foreach (GameObject obj in objects)
                        {

                            isBlockBelow = isBlockBelow || detector.DetectCollision(obj, gameTime);
                        }
                        if (!isBlockBelow)
                        {
                            CurrentActionState.ChangeToFalling();
                        }
                        Sprite.Position -= new Vector2(0, 8);
                    }
                    {
                        // Move the sprite by acceleration, scaled by elapsed time.
                        Sprite.Velocity += Sprite.Acceleration * (float)gameTime.ElapsedGameTime.TotalSeconds;
                        Sprite.Velocity = CurrentActionState.ClampVelocity(Sprite.Velocity);
                        Sprite.Position += Sprite.Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
                        Sprite.Position = Vector2.Clamp(Sprite.Position, new Vector2(leftBound, 0), new Vector2(3574, graphics.PreferredBackBufferHeight + 60));
                    }

                    Sprite.Update(gameTime, graphics);
                    CurrentPowerUpState.Update(gameTime, graphics);
                    CurrentActionState.Update(gameTime, graphics);
                }

                else
                {
                    if (isDownPipe > 0)
                    {
                        Sprite.Update(gameTime, graphics);
                        Sprite.Position = new Vector2(Position.X, Position.Y + 1);
                        isDownPipe--;
                    }
                    else
                    {
                        Sprite.Update(gameTime, graphics);
                        Sprite.Position = new Vector2(Position.X, Position.Y - 1);
                        isDownPipe++;
                    }
                    if (isDownPipe == 0)
                    {
                        Console.WriteLine("Coin room\n");

                        Game1.Game.ResetCommand(true);
                    }


                }
              
                

            }
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            // SpriteSheet has sprite definitions facing RIGHT
            if (Direction == eDirection.Left)
                Sprite.SpriteEffects = SpriteEffects.FlipHorizontally;
            else
                Sprite.SpriteEffects = SpriteEffects.None;
            this.Sprite.DrawAABB = Mario.displayBorder;
            Sprite.Draw(spriteBatch);
        }

        public void VictoryTrigger()
        {
            isVictory = true;
            if (CurrentPowerUpState is MarioStandardState)
            {
                Sprite.texture = Game1.Game.Content.Load<Texture2D>("Characters/Mario/marioStandardClimbPole");

            }
            else if (CurrentPowerUpState is MarioFireState)
            {
                Sprite.texture = Game1.Game.Content.Load<Texture2D>("Characters/Mario/fireMarioPoleClimbing");

            }
            else if (CurrentPowerUpState is MarioSuperState)
            {
                Sprite.texture = Game1.Game.Content.Load<Texture2D>("Characters/Mario/superMarioPoleClimbing");

            }
            else
            {

            }
        }

        public int PointFromFlag()
        {
            int pointPosition = (int)Position.Y - 64;
            int points;

            if (pointPosition >= 135)
            {
                points = 100;
            }
            else if (pointPosition >= 95)
            {
                points = 400;
            }
            else if (pointPosition >= 71)
            {
                points = 800;
            }
            else if (pointPosition >= 25)
            {
                points = 2000;
            }
            else
            {
                points = 4000;
            }
            return points;
        }

        // Command Handlers
        public void ChangeToStanding() { CurrentActionState.ChangeToStanding(); }
        public void ChangeToCrouching()
        {
           if (Warp())
           {
               Game1.Game.MarioAnimatedPipe();
           }
           else
           {
               CurrentActionState.ChangeToCrouching();
           }
        }
        public void ChangeToLeftFacing() { CurrentActionState.ChangeToLeftFacing(); }
        public void ChangeToRightFacing() { CurrentActionState.ChangeToRightFacing(); }
        public void ChangeToRunning() { CurrentActionState.ChangeToRunning(); }
        public void ChangeToJumping() { CurrentActionState.ChangeToJumping(); }
        public void ChangeToFalling() { CurrentActionState.ChangeToFalling(); }

        public void StopChangeToCrouch() { CurrentActionState.StopChangeToCrouch(); }
        public void StopChangeToLeftFacing() { CurrentActionState.StopChangeToLeftFacing(); }
        public void StopChangeToRightFacing() { CurrentActionState.StopChangeToRightFacing(); }
        public void StopChangeToWalking() { CurrentActionState.StopChangeToWalking(); }
        public void StopChangeToRunning() { CurrentActionState.StopChangeToRunning(); }
        public void StopChangeToJumping() { CurrentActionState.StopChangeToJumping(); }


        public void ChangeToStandardState() { isFire = false; invincible = true; IMarioPowerUpState previousPowerUpState = CurrentPowerUpState; CurrentPowerUpState.Exit(); CurrentPowerUpState = PowerUpStateMachine.StateMarioStandard; CurrentPowerUpState.Enter(previousPowerUpState); /*CurrentActionState.Enter(CurrentActionState.PreviousActionState);*/ }
        public void ChangeToSuperState() { isFire = false; invincible = true;  IMarioPowerUpState previousPowerUpState = CurrentPowerUpState; CurrentPowerUpState.Exit(); CurrentPowerUpState = PowerUpStateMachine.StateMarioSuper; CurrentPowerUpState.Enter(previousPowerUpState); /*CurrentActionState.Enter(CurrentActionState.PreviousActionState);*/ }
        public void ChangeToFireState() { isFire = true;  invincible = true; IMarioPowerUpState previousPowerUpState = CurrentPowerUpState; CurrentPowerUpState.Exit(); CurrentPowerUpState = PowerUpStateMachine.StateMarioFire; CurrentPowerUpState.Enter(previousPowerUpState); /*CurrentActionState.Enter(CurrentActionState.PreviousActionState);*/ }
        public void ChangeToStarState() { isFire = false; invincible = true; IMarioPowerUpState previousPowerUpState = CurrentPowerUpState; CurrentPowerUpState.Exit(); CurrentPowerUpState = PowerUpStateMachine.StateMarioInvincible; CurrentPowerUpState.Enter(previousPowerUpState); /*CurrentActionState.Enter(CurrentActionState.PreviousActionState);*/ }
        public void ChangeToSuperStarState() { isFire = false; invincible = true; IMarioPowerUpState previousPowerUpState = CurrentPowerUpState; CurrentPowerUpState.Exit(); CurrentPowerUpState = PowerUpStateMachine.StateMarioSuperInvincible; CurrentPowerUpState.Enter(previousPowerUpState); /*CurrentActionState.Enter(CurrentActionState.PreviousActionState);*/ }
        public void TakeDamage() {
            this.mySound = Game1.Game.Content.Load<SoundEffect>("Sounds/scream");
            if (!MediaPlayer.IsMuted)
            {
                this.mySound.Play(volume: .5f, pitch: 0f, pan: 0f);
            }
            CurrentPowerUpState.TakeDamage();
        }

        public void ThrowFireball() { CurrentPowerUpState.ThrowFireball(); }
        public bool Warp()
        {
            Console.WriteLine("Entered Warp\n");
            List<GameObject> objs = Game1.Game.grid.PossibleCollisions((int)Position.X, (int)Position.Y);
            
            foreach (GameObject obj in objs)
            {
                if (obj.Sprite.whatAmI == Sprite.id.Pipe)
                {
                    Console.WriteLine("Is pipe\n");

                    if (((WarpPipe)obj).tele == 1 || ((WarpPipe)obj).tele == 2)
                    {
                        Console.WriteLine("Is Warp\n");

                        if (Velocity == Vector2.Zero && Position.X + 8 >= obj.Position.X + 16 - 4 && Position.X + 8 <= Position.X + 16 + 4)
                        {
                            Console.WriteLine("Pos match\n");

                            return true;
                        }
                    }
                }
            }
            return false;
        } 

                
    }
}

