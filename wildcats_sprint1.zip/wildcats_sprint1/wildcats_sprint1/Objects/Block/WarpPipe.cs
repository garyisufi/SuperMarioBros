﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects.Enemy;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.Block
{
    public class WarpPipe : GameObject
    {
        Piranha pir2;
        public int tele;
        public WarpPipe(Vector2 position, Sprite sprite, Piranha p, int telePipe)
            : base(position, sprite)
        {
            this.Position = position;
            this.Sprite = sprite;
            pir2 = p;
            tele = telePipe;
            Sprite.whatAmI = Sprite.id.Pipe;
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {

            Sprite.Update(gameTime, graphics);

            
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            
            Sprite.Draw(spriteBatch);
        }
    }
}
