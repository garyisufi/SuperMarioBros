﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.Block
{
    public class BlockObject : GameObject
    {
        public BlockObject(Vector2 position, BlockSprite sprite):base(position, sprite)
        {
            

        }
        public virtual void HitFromBelow()
        {

        }
    }
}
