﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.Score;

namespace wildcats_sprint1.Objects.Block
{
    public class QuestionBlock : BlockObject
    {

        public Item item;
        private Boolean isHidden;
        public QuestionBlock(Vector2 position, BlockSprite sprite,  Boolean hidden, Item item2)
            : base(position, sprite)
        {
            Velocity = new Vector2(0, 0);
           
            isHidden = hidden;
            if (hidden)
            {
                sprite.whatAmI = Sprite.id.HiddenBlock;
                texture = Game1.Game.Content.Load<Texture2D>("Blocks/HiddenBlock");
            }
            else
            {
                sprite.whatAmI = Sprite.id.QuestionBlock;
            }
            item = item2;
        }
        public override void HitFromBelow()
        {
            if (isHidden)
            {
                isHidden = false;
                Sprite.whatAmI = Sprite.id.OtherBlock;
            }
            texture = Game1.Game.Content.Load<Texture2D>("Blocks/UsedBlock");
            Sprite.isAnimated = false;
            Sprite.sheetSize = 1;
            Sprite.currentFrame = 0;
            item.isRevealed = true;
            item.SetStartDirection();
            if (item is Coin)
            {
                Scoreboard.getInstance().score += 100;
            }
        }
    }
}
