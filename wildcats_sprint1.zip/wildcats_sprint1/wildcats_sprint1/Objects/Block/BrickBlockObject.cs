﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Objects.Block
{
    public class BrickBlockObject : BlockObject
    {
        private bool isHidden;
        public BrickBlockObject(Vector2 position, BrickBlock sprite, bool hidden, int coins, Coin c)
            : base(position, sprite)
        {
            Velocity = new Vector2(0, 0);
            isHidden = hidden;
            if(hidden)
            {
                sprite.whatAmI = Sprite.id.HiddenBlock;
            }
            else
            {
                sprite.whatAmI = Sprite.id.BrickBlock;
            }
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            if (!isHidden)
            {
                base.Draw(spriteBatch);
            }
        }
        public override void HitFromBelow()
        {
            if(isHidden)
            {
                isHidden = false;
                Sprite.whatAmI = Sprite.id.BrickBlock;
            }

        }
        public  void BreakBlock()
        {
            ((BrickBlock)Sprite).Break();
        }
        public  void BumpBlock()
        {
            ((BrickBlock)Sprite).Bump();
        }



    }
}
