﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.States;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.Collisions;

namespace wildcats_sprint1.Objects
{
    public class GameObject : ISprite
    {
        // Direction that mario is facing in the current action and power-up states
        public eDirection Direction
        {
            get { return Sprite.Direction; }
            set { Sprite.Direction = value; }
        }
        public ICollider collider {get;set;}
        public IDetector detector { get; set;}
        public AABB AABB
        {
            get { return Sprite.AABB; }
            set { Sprite.AABB = value; }
        }
        public Vector2 Velocity
        {
            get { return Sprite.Velocity; }
            set { Sprite.Velocity = value; }
        }

        public Sprite Sprite { get; set; }
        public Texture2D texture
        {
            get { return Sprite.texture; }
            set { Sprite.texture = value; }
        }

        public Vector2 Position
        {
            get { return AABB.Position; }
            set { AABB.Position = value; }
        }
        public int height
        {
            get { return Sprite.texture.Height; }
        }
        public int width
        {
            get { return Sprite.texture.Width; }
        }
        public GameObject(Vector2 position, Sprite sprite)
        {
            this.Sprite = sprite;
            this.Position = position;


        }
        public GameObject(Vector2 position, Vector2 velocity, Sprite sprite)
        {
            this.Sprite = sprite;
            this.Velocity = velocity;
            this.Position = position;
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            Sprite.Draw(spriteBatch);
        }
        public virtual void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            Sprite.Update(gameTime, graphics);
        }

        public string Color()
        {
            return Sprite.AABBColor.ToString();
        }
      
    }
}
