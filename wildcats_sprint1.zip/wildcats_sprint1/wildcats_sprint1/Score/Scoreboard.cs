﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.Score
{
    public class Scoreboard
    {
        public int score { get; set; }
        public int time;
        private int timeIncrement;
        private int elapsedTime;
        private int lives;
        private int coins;
        GraphicsDeviceManager graphics;
        SpriteBatch spritebatch;
        private SpriteFont font;

        //Make modified singleton. Requires initialization in game1 but avoids requiring making graphics and spritebatch public in game1
        private static Scoreboard instance;
        public static Scoreboard getInstance()
        {
            return instance;
        }

        public Scoreboard(SpriteBatch spritebatch, GraphicsDeviceManager graphics)
        {
            this.graphics = graphics;
            this.spritebatch = spritebatch;
            time = 300;
            timeIncrement = 600;
            lives = 3;
            score = 0;
            elapsedTime = 0;
            coins = 0;
            font = Game1.Game.Content.Load<SpriteFont>("File");
            instance = this;
            
        }

        public void Update(GameTime gametime)
        {
            elapsedTime += gametime.ElapsedGameTime.Milliseconds;
            if (elapsedTime > timeIncrement)
            {
                elapsedTime -= timeIncrement;
                time--;
            }
        }
        public void GetCoin()
        {
            this.score += 1000;
            this.coins += 1;
            if (this.coins >= 100)
            {
                this.coins = 0;
                Game1.Game.allowedResets += 1;
            }
        }
        public void Draw()
        {
            Vector2 namePosition = new Vector2(16, 16);
            Vector2 pointsPosition =  new Vector2(16, 32);
            Vector2 coinsPosition = new Vector2(256, 32);
            Vector2 worldPosition =  new Vector2(512, 16);
            Vector2 timeNamePosition = new Vector2(768, 16);
            Vector2 timePosition = new Vector2(768, 32);



            spritebatch.Begin();
            spritebatch.DrawString(font, "Itsame a mario", namePosition, Color.White);
            spritebatch.DrawString(font, score.ToString(), pointsPosition, Color.White);
            spritebatch.DrawString(font, "Coin X " + coins.ToString(), coinsPosition, Color.White);
            spritebatch.DrawString(font, "World \n 1-1", worldPosition, Color.White);
            spritebatch.DrawString(font, "Time", timeNamePosition, Color.White);
            spritebatch.DrawString(font, time.ToString(), timePosition, Color.White);
            spritebatch.End();      
        }
    }
}
