﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Collisions
{
    public class AABB
    {
        private Vector2 _position;
        private Vector2 _size;

        public Vector2 Velocity { get; set; }
        public Vector2 Acceleration { get; set; }

        //Bounding Box for use in collisions of mario with world objects
        public Rectangle BoundingBox()
        {
            return new Rectangle((int)_position.X, (int)_position.Y, (int)_size.X, (int)_size.Y);
        }

        public AABB(Vector2 topLeft, Vector2 size, Vector2 velocity, Vector2 acceleration)
        {
            _position = topLeft;
            _size = size;
            Velocity = velocity;
            Acceleration = acceleration;
        }

        public AABB(Rectangle boundingBox, Vector2 velocity, Vector2 acceleration)
        {
            _position.X = boundingBox.X;
            _position.Y = boundingBox.Y;
            _size.X = boundingBox.Width;
            _size.Y = boundingBox.Height;

            Velocity = velocity;
            Acceleration = acceleration;
        }

        public AABB(Rectangle boundingBox)
            : this(boundingBox, Vector2.Zero, Vector2.Zero)
        {
        }

        public AABB(float x, float y, float width, float height)
        {
            _position.X = x;
            _position.Y = y;
            _size.X = width;
            _size.Y = height;
            Velocity = Vector2.Zero;
        }

        public Vector2 Position
        {
            get { return _position; }
            set { _position = value; }
        }
        public float X
        {
            get { return _position.X; }
            set { _position.X = value; }
        }

        public float Y
        {
            get { return _position.Y; }
            set { _position.Y = value; }
        }

        public Vector2 Size
        {
            get { return _size; }
            set { _size = value; }
        }

        public float Width
        {
            get { return _size.X; }
            set { _size.X = value; }
        }

        public float Height
        {
            get { return _size.Y; }
            set { _size.Y = value; }
        }

        public void Physics(Vector2 position, Vector2 velocity, Vector2 acceleration)
        {
            Position = position;
            Velocity = velocity;
            Acceleration = acceleration;
        }

        public Vector2 ForecastedVelocity(float step)   // step = elapsedGameTime.TotalSeconds
        {
            Vector2 velocity = Velocity;
            velocity += Acceleration * step;
            return velocity * step;
        }
    }
}
