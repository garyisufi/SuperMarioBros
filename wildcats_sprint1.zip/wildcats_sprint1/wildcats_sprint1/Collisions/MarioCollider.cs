﻿using Microsoft.Xna.Framework;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.Block;
using wildcats_sprint1.Objects.Enemy;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.SpriteClasses;
using wildcats_sprint1.States.Powerups;
using wildcats_sprint1.Score;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using System;

namespace wildcats_sprint1.Collisions
{

    public class MarioCollider:ICollider
    {
        
        private Mario mario;
        private Vector2 pos;
        private SoundEffect mySound;
        public MarioCollider(Mario mar)
        {
            mario = mar;
            pos = mario.Position;
        }
        public void ExecuteCollision(GameObject obj, int dir)
        {
            switch(obj.Sprite.whatAmI)
            {
                case Sprite.id.Goomba:
                case Sprite.id.Koopa:
                {
                    if (!mario.deathReset)
                    {
                            if (dir == 1)
                            {
                                Scoreboard.getInstance().score = Scoreboard.getInstance().score + 200;
                                ((Enemy)obj).changeToDead();
                                this.mySound = Game1.Game.Content.Load<SoundEffect>("Sounds/guessyouhaventheard");
                                if (!MediaPlayer.IsMuted)
                                {
                                    this.mySound.Play(volume: .5f, pitch: 0f, pan: 0f);
                                }
                                mario.CurrentActionState.BouncingTransition();
                            }
                            else
                            {
                                mario.TakeDamage();
                                switch (dir)
                                {
                                    case 0:
                                        mario.Position = mario.Position;
                                        break;
                                    case 2:
                                        mario.Position = new Vector2(mario.Position.X, mario.Position.Y);
                                        break;
                                    case 3:
                                        mario.Position = new Vector2(mario.Position.X, mario.Position.Y);
                                        break;
                                }
                                mario.Velocity = Vector2.Zero;


                            }
                    }
                    break;
                }

                case Sprite.id.OtherBlock:
                {
                        switch (dir) {
                            case 0:
                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y + obj.AABB.Height + 2);
                                mario.ChangeToFalling();
                                break;
                            case 1:
                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y - mario.AABB.Height);
                                mario.ChangeToStanding();
                                break;
                            case 3:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X- mario.AABB.Width-2, mario.Position.Y );
                                break;
                            case 2:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X + obj.AABB.Width + 2, mario.Position.Y);
                                break;
                        }
                        break;
                }

                case Sprite.id.HiddenBlock:
                {
                        if(dir == 0)
                        {
                            mario.Velocity = new Vector2(mario.Velocity.X, 0);
                            mario.Position = new Vector2(mario.Position.X, obj.Position.Y + obj.AABB.Height + 2);
                            
                        }
                        break;
                    }
                    case Sprite.id.BrickBlock:
                    {
                        switch (dir)
                        {
                            case 0:

                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y + obj.AABB.Height + 2);
                                if (mario.CurrentPowerUpState is MarioStandardState || mario.CurrentPowerUpState is MarioStarState)
                                {
                                    ((BrickBlockObject)obj).BumpBlock();
                                }
                                else
                                {
                                    ((BrickBlockObject)obj).BreakBlock();
                                }
                                break;
                            case 1:
                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y - mario.AABB.Height);
                                mario.ChangeToStanding();
                                break;
                            case 3:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X - mario.AABB.Width - 2, mario.Position.Y);
                                break;
                            case 2:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X + obj.AABB.Width + 2, mario.Position.Y);
                                break;
                                
                        }
                        break;
                            
                    }
                case Sprite.id.QuestionBlock:
                    {
                        switch (dir)
                        {
                            case 0:
                                ((QuestionBlock)obj).HitFromBelow();
                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y + obj.AABB.Height + 2);
                                break;
                            case 1:
                                mario.Velocity = new Vector2(mario.Velocity.X, 0);
                                mario.Position = new Vector2(mario.Position.X, obj.Position.Y - mario.AABB.Height);
                                mario.ChangeToStanding();
                                break;
                            case 3:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X - mario.AABB.Width - 2, mario.Position.Y);
                                break;
                            case 2:
                                mario.Velocity = new Vector2(0, mario.Velocity.Y);
                                mario.Position = new Vector2(obj.Position.X + obj.AABB.Width + 2, mario.Position.Y);
                                break;
                        }
                        break;
                    }
                case Sprite.id.FireFlower:
                {
                    if(((Item)obj).isFullyRevealed)
                        {
                        mario.ChangeToFireState();
                        Scoreboard.getInstance().score += 1000;
                        ((Item)obj).PickUp();
                    }
                    break;
                }
                case Sprite.id.RedMushroom:
                {
                    if (((Item)obj).isFullyRevealed)
                    {
                        mario.ChangeToSuperState();
                        ((Item)obj).PickUp();
                        Scoreboard.getInstance().score += 1000;

                    }
                    break;
                }
                case Sprite.id.Star:
                {
                    if (((Item)obj).isFullyRevealed)
                    {
                        if (mario.CurrentPowerUpState is MarioStandardState)
                        {
                            mario.ChangeToStarState();
                            ((Item)obj).PickUp();
                        }
                        else if (mario.CurrentPowerUpState is MarioSuperState || mario.CurrentPowerUpState is MarioFireState)
                        {
                            mario.ChangeToSuperStarState();
                            ((Item)obj).PickUp();
                        }
                        Scoreboard.getInstance().score += 1000;

                    }
                    break;
                }
                case Sprite.id.GreenMushroom:
                {
                    if (((Item)obj).isFullyRevealed)
                    {
                        ((Item)obj).PickUp();
                        Scoreboard.getInstance().score += 1000;
                        Game1.Game.allowedResets++;
                    }
                    break;
                }
                case Sprite.id.Coin:
                {
                        ((Item)obj).PickUp();
                        Scoreboard.getInstance().GetCoin();
                        break;
                }

                case Sprite.id.Pipe:
                {
                        //mario.Velocity = Vector2.Zero;
                        //mario.Position = new Vector2(mario.Position.X, mario.Position.Y - 2);
                        //mario.Sprite.Acceleration = new Vector2(0, 0);
                        if (dir == 1)
                        {
                            mario.Velocity = Vector2.Zero;
                            mario.Position = new Vector2(mario.Position.X, mario.Position.Y - 2);
                            mario.Sprite.Acceleration = new Vector2(0, 0);
                            mario.ChangeToStanding();
                        }
                        else if (dir == 3)
                        {
                            mario.Velocity = new Vector2(0, mario.Position.Y);
                            mario.Position = new Vector2(mario.Position.X - 2, mario.Position.Y);
                        }
                        else if (dir == 2)
                        {
                            mario.Velocity = new Vector2(0, mario.Position.Y);
                            mario.Position = new Vector2(mario.Position.X + 2, mario.Position.Y);
                        }

                        
                        break;
                   
                }
                case Sprite.id.Piranha:
                {
                        mario.TakeDamage();
                        break;
                }
                case Sprite.id.Flag:
                {
                        //Console.WriteLine("VictoryTriggerEntrance");
                        //mario.VictoryTrigger();

                    break;
                }
            }
        }        
        
        

}
}
