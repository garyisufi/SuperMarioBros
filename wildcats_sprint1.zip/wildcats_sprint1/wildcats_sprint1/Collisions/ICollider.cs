﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Collisions
{
    public interface ICollider
    {
        void ExecuteCollision(GameObject obj, int dir);
    }
}
