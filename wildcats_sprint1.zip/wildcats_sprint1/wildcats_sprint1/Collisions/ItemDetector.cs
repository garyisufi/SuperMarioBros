﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.ItemObjects;

namespace wildcats_sprint1.Collisions
{
    public class ItemDetector : IDetector
    {
        private Item item;
        public bool Collidable { get; set; }
        public ItemDetector(Item i)
        {
            item = i;
            Collidable = true;
        }
        public int CollisionDirection()
        {
            int dir = 3;
            if (Math.Abs(item.Velocity.Y) > Math.Abs(item.Velocity.X))
            {
                dir -= 2;
                if (item.Velocity.Y < 0)
                {
                    dir--;
                }
            }
            else if (item.Velocity.X < 0)
            {
                dir--;
            }

            return dir;
        }

        public bool DetectCollision(GameObject obj, GameTime gameTime)
        {
            return item.AABB.BoundingBox().Intersects(obj.AABB.BoundingBox()) && Collidable;
        }
    }
}
