﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Collisions
{
    public class ItemCollider : ICollider
    {
        private Item item;
        public ItemCollider(Item i)
        {
            item = i;
        }
        public void ExecuteCollision(GameObject obj, int dir)
        {
           switch(obj.Sprite.whatAmI)
            {
                case Sprite.id.BrickBlock:
                case Sprite.id.QuestionBlock:
                case Sprite.id.OtherBlock:
                    if (item.isFullyRevealed)
                    {
                        if (dir == 1)
                        {
                            item.Velocity = new Vector2(item.Velocity.X, 0);
                            item.Position = new Vector2(item.Position.X, item.Position.Y - 3);
                        }
                        else
                        {
                            item.Velocity = new Vector2(-1 * item.Velocity.X, item.Velocity.Y);
                        }
                    }
                    break;
                
            }
        }
    }
}
