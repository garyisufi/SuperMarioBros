﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.Enemy;

namespace wildcats_sprint1.Collisions
{
    public class EnemyDetector : IDetector
    {
        private Enemy enemy;
        public bool Collidable { get; set; }
        public EnemyDetector(Enemy e)
        {
            enemy = e;
            Collidable = true;
        }
        public int CollisionDirection()
        {
            int dir = 3;
            if (Math.Abs(enemy.Velocity.Y) > Math.Abs(enemy.Velocity.X))
            {
                dir -= 2;
                if (enemy.Velocity.Y < 0)
                {
                    dir--;
                }
            }
            else if (enemy.Velocity.X < 0)
            {
                dir--;
            }

            return dir;
        }

        public bool DetectCollision(GameObject obj, GameTime gameTime)
        {

                return enemy.AABB.BoundingBox().Intersects(obj.AABB.BoundingBox()) && obj != enemy && Collidable;
        }
    }
}
