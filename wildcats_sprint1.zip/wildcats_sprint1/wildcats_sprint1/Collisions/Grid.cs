﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Collisions
{
    public class Grid
    {
        private List<GameObject>[,] grid;
        private int width;
        private int height;
        public Grid(int x, int y)
        {
            grid = new List<GameObject>[x / 32, y / 32];
            width = x / 32;
            height = y / 32;
        }
        public void Add(GameObject obj)
        {
            
                if ((int)obj.Position.X / 32 >= 0 && (int)obj.Position.X / 32 < width && (int)obj.Position.Y / 32 >= 0 && (int)obj.Position.Y / 32 < height)
                {
                    if (grid[(int)obj.Position.X / 32, (int)obj.Position.Y / 32] == null)
                    {
                        grid[(int)obj.Position.X / 32, (int)obj.Position.Y / 32] = new List<GameObject>();
                    }
                    grid[(int)obj.Position.X / 32, (int)obj.Position.Y / 32].Add(obj);
                }
            
                
        }
        public void Remove(GameObject obj)
        {
            if (obj.Position.X / 32 >= 0 && obj.Position.X / 32 < width && (int)obj.Position.Y / 32 >= 0 && (int)obj.Position.Y / 32 < height)
            {
                if (grid[(int)obj.Position.X / 32, (int)obj.Position.Y / 32] != null)
                {
                    grid[(int)obj.Position.X / 32, (int)obj.Position.Y / 32].Remove(obj);
                }
            }
        }
        public List<GameObject> PossibleCollisions(int x, int y)
        {
            List<GameObject> Collidables = new List<GameObject>();
            x /= 32;
            y /= 32;
            for (int i = x-1; i <= x+1; i++)
                for (int j = y-1; j <= y+1; j++)
                    if (!(i < 0 || j < 0 || i >= width || j >= height))
                    {
                        List<GameObject> temp = grid[i, j];
                        if (temp != null)
                        {
                            foreach (GameObject obj in temp)
                                Collidables.Add(obj);
                        }
                     }
                    
            return Collidables;
        }

        public void Clear()
        {
            var count = 0;
            var count2 = 0;
            for (count = 0; count < width; count++)
            {
                for (count2 = 0; count2 < height; count2++)
                {
                    grid[count, count2]?.Clear();
                }
            }
        }
        public List<GameObject> get(int x, int y)
        {
            return grid[x, y];
        }
    }
}
