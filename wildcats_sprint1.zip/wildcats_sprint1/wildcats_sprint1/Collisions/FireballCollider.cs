﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.ItemObjects;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Collisions
{
    public class FireballCollider : ICollider
    {
        private Fireball fireball;
        public FireballCollider(Fireball i)
        {
            fireball = i;
        }
        public void ExecuteCollision(GameObject obj, int dir)
        {
            switch (obj.Sprite.whatAmI)
            {
                case Sprite.id.Goomba:
                case Sprite.id.QuestionBlock:
                case Sprite.id.OtherBlock:
                    if (fireball.isFullyRevealed)
                    {
                        if (dir == 1)
                        {
                            fireball.Velocity = new Vector2(fireball.Velocity.X, 0);
                            fireball.Position = new Vector2(fireball.Position.X, fireball.Position.Y - 3);
                        }
                        else
                        {
                            fireball.Velocity = new Vector2(-1 * fireball.Velocity.X, fireball.Velocity.Y);
                        }
                    }
                    break;

            }
        }
    }
}
