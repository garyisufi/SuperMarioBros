﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;
using wildcats_sprint1.Objects.Enemy;
using wildcats_sprint1.Objects.Enemy.States.Actions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Collisions
{
    public class EnemyCollider : ICollider
    {
        private Enemy enemy;
        public EnemyCollider(Enemy e)
        {
            enemy = e;
        }
        public void ExecuteCollision(GameObject obj, int dir)
        {
            
                switch (obj.Sprite.whatAmI)
                {
                    case Sprite.id.OtherBlock:
                    case Sprite.id.BrickBlock:
                    case Sprite.id.QuestionBlock:
                        {
                            
                            if ((int)enemy.Velocity.Y != 0)
                            {
                            enemy.Position = new Vector2(enemy.Position.X, enemy.Position.Y -5);
                                enemy.changeToMoving();
                                
                                
                        }
                            else
                            {
                            enemy.Velocity = new Vector2(enemy.Velocity.X * -1, 0);
                            }
                            break;
                        }
                    case Sprite.id.Koopa:
                    case Sprite.id.Goomba:
                        {
                            enemy.Velocity = new Vector2(enemy.Velocity.X * -1, enemy.Velocity.Y);
                            break;
                        }
                    case Sprite.id.Pipe:
                        enemy.Velocity = new Vector2(enemy.Velocity.X * -1, enemy.Velocity.Y);
                        break;

                
            }
        }
    }
}
