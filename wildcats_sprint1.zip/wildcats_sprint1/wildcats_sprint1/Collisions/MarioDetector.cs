﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Collisions
{
    public class MarioDetector:IDetector
    {
        private Mario mario;
        public bool Collidable { get; set; }
        public MarioDetector(Mario mar)
        {
            mario = mar;
            Collidable = true;
        }
        public bool DetectCollision(GameObject obj, GameTime gameTime)
        {
            //This mostly works but gets a little teleporty on blocks for some reason. Went to the not forcast version which is more consistant
            //Vector2 futureVelocity = mario.AABB.ForecastedVelocity((float)gameTime.ElapsedGameTime.TotalSeconds);
            //Vector2 futurePosition = mario.Position + futureVelocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
            //return new Rectangle((int)futurePosition.X, (int)futurePosition.Y, (int)mario.AABB.Width, (int)mario.AABB.Height).Intersects(obj.AABB.BoundingBox());
            return mario.AABB.BoundingBox().Intersects(obj.AABB.BoundingBox()) && Collidable;
        }
        public int CollisionDirection()
        {
            //if X > Y & X > 0 dir stays 3, moving right
            //if X > Y & X < 0 dir-- becomes 2. moving left
            //if Y > X & Y > 0 dir -=2 becomes 1 moving down
            //if Y > X & Y < 0 dir--2, dir-- becomes 0 moving up
            int dir = 3;
            if (Math.Abs(mario.Velocity.Y) > Math.Abs(mario.Velocity.X))
            {
                dir -= 2;
                if (mario.Velocity.Y < 0)
                {
                    dir--;
                }
            }
            else if(mario.Velocity.X < 0)
            {
                dir--;
            }

            return dir;
            
        }
    }
}
