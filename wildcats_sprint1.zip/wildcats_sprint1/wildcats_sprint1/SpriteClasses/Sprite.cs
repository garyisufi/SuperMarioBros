﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Collisions;

namespace wildcats_sprint1.SpriteClasses
{
    public abstract class Sprite : ISprite
    {

        // ISprite
        private eDirection direction = eDirection.Right;
        public eDirection Direction
        {
            get { return direction; }
            set { direction = value; }
        }
        public enum id
        {
            RedMushroom = 0,
            FireFlower = 1,
            HiddenBlock = 2,
            OtherBlock = 3,
            Goomba = 4,
            NoEffect = 5,
            Star = 6,
            Koopa = 7,
            GreenMushroom = 8,
            QuestionBlock = 9,
            BrickBlock = 10,
            Coin = 11, 
            Fireball = 12,
            Pipe = 13,
            Piranha = 14,
            Flag = 15,
        }
        public id whatAmI { get; set; } 
        Sprite ISprite.Sprite
        {
            get { return this; }
        }

        public Texture2D texture { get; set; }

        public virtual Vector2 Position
        {
            get { return AABB.Position; }
            set { AABB.Position = value; }
        }

        public float X
        {
            get { return AABB.X; }
            set { AABB.X = value; }
        }

        public float Y
        {
            get { return AABB.Y; }
            set { AABB.Y = value; }
        }

        public Vector2 Size
        {
            get { return AABB.Size; }
            set { AABB.Size = value; }
        }

        public float Width
        {
            get { return AABB.Width; }
            set { AABB.Width = value; }
        }

        public float Height
        {
            get { return AABB.Height; }
            set { AABB.Height = value; }
        }

        public Vector2 Velocity
        {
            get { return AABB.Velocity; }
            set { AABB.Velocity = value; }
        }

        public Vector2 Acceleration
        {
            get { return AABB.Acceleration; }
            set { AABB.Acceleration = value; }
        }

        public Rectangle Rect
        {
            get
            {
                return AABB.BoundingBox();
            }
        }

        // Sprite
        public bool isAnimated;


        public bool IsAnimated
        {
            get { return isAnimated; }
            set { isAnimated = value; }
        }

        public Point FrameSize { get; set; }

        public SpriteEffects SpriteEffects { get; set; }
           

        public int currentFrame = 0;

        public int sheetSize;


        private int animationFrame = 0;
        public int AnimationFrame
        {
            get { return animationFrame; }
            set { animationFrame = value; }
        }

        private Boolean isAnimationFrameRecycling = false;

        public Boolean IsAnimationFrameRecycling
        {
            get { return isAnimationFrameRecycling; }
            set { isAnimationFrameRecycling = value; }
        }
        private int nextFrameIncrement = 1;

        public int NextFrameIncrement
        {
            get { return nextFrameIncrement; }
            set { nextFrameIncrement = value; }
        }

        private int timeSinceLastFrame = 0;
        public int TimeSinceLastFrame
        {
            get { return timeSinceLastFrame; }
            set { timeSinceLastFrame = value; }
        }

        private int millisecondsPerFrame = 500;

        public int MillisecondsPerFrame
        {
            get { return millisecondsPerFrame; }
            set { millisecondsPerFrame = value; }
        }

        private static Texture2D pixel;
        private Texture2D Pixel
        {
            get { return pixel; }
            set { pixel = value; }
        }

        // describes an axis-aligned rectangle with a velocity
        public AABB AABB { get; set; }

        private bool _DrawAABB = false;

        public bool DrawAABB
        {
            get { return _DrawAABB /*|| XNATheatre.Theatre.Scene.Script.ShowSpriteBorders*/; }
            set { _DrawAABB = value; }
        }

        public Color AABBColor { get; set; }
        

        protected Sprite(Texture2D texture, Point frameSize, int sheetSize, Vector2 position, Vector2 velocity, Vector2 acceleration, bool isAnimated, Color type)
        {
            if (type == Color.Red)
            {
                this.AABB = new AABB(new Vector2(position.X + 2, position.Y + 2), new Vector2(frameSize.X - 4, frameSize.Y - 4), velocity, acceleration);
                AABBColor = Color.Red;
            }
            else if (type == Color.Green)
            {
                this.AABB = new AABB(new Vector2(position.X - 2, position.Y - 2), new Vector2(frameSize.X + 4, frameSize.Y + 4), velocity, acceleration);
                AABBColor = Color.Green;
            }
            else if (type == Color.Blue)
            {
                this.AABB = new AABB(position, new Vector2(frameSize.X, frameSize.Y), velocity, acceleration);
                AABBColor = Color.Blue;
            }
            else if (type == Color.Yellow)
            {
                this.AABB = new AABB(position, new Vector2(frameSize.X, frameSize.Y), velocity, acceleration);
                AABBColor = Color.Yellow;
            }
            else
            {
                this.AABB = new AABB(position, new Vector2(frameSize.X, frameSize.Y), velocity, acceleration);
                AABBColor = Color.White;
            }
            this.texture = texture;
            this.FrameSize = frameSize;
            this.sheetSize = sheetSize;
            this.isAnimated = isAnimated;
            


            SpriteEffects = SpriteEffects.None;
        }

        public virtual void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (Pixel == null)
            {
                Pixel = new Texture2D(graphics.GraphicsDevice, 1, 1, false, SurfaceFormat.Color);
                Pixel.SetData(new[] { Color.White });
            }

            NextFrame(gameTime);
        }

        protected virtual void NextFrame(GameTime gameTime)
        {
            if (isAnimated)
            {
                timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
                if (timeSinceLastFrame > MillisecondsPerFrame)
                {
                    timeSinceLastFrame -= MillisecondsPerFrame;

                    animationFrame += NextFrameIncrement;
                    if (NextFrameIncrement > 0 &&
                        AnimationFrame >= sheetSize)     // Upper Limit Check
                    {
                       
                            NextFrameIncrement *= -1;
                        animationFrame += NextFrameIncrement * 2;
                    }
                    else
                    if (NextFrameIncrement < 0 &&
                        AnimationFrame < 0)
                    {
                            NextFrameIncrement *= -1;
                            animationFrame += NextFrameIncrement*2;
                    }

                    currentFrame = AnimationFrame;
                }
            }
        }

        public void DrawBorder(SpriteBatch spriteBatch, Rectangle rectangleToDraw, int thicknessOfBorder, Color borderColor)
        {
            // Draw top line
            spriteBatch.Draw(Pixel, new Rectangle(rectangleToDraw.X, rectangleToDraw.Y, rectangleToDraw.Width, thicknessOfBorder), null, borderColor, 0f, Vector2.Zero, SpriteEffects.None, 1.0f - .005f);

            // Draw left line
            spriteBatch.Draw(Pixel, new Rectangle(rectangleToDraw.X, rectangleToDraw.Y, thicknessOfBorder, rectangleToDraw.Height), null, borderColor, 0f, Vector2.Zero, SpriteEffects.None, 1.0f - .005f);

            // Draw right line
            spriteBatch.Draw(Pixel, new Rectangle((rectangleToDraw.X + rectangleToDraw.Width - thicknessOfBorder),
                                                    rectangleToDraw.Y,
                                                    thicknessOfBorder,
                                                    rectangleToDraw.Height), null, borderColor, 0f, Vector2.Zero, SpriteEffects.None, 1.0f - .005f);
            // Draw bottom line
            spriteBatch.Draw(Pixel, new Rectangle(rectangleToDraw.X,
                                                    rectangleToDraw.Y + rectangleToDraw.Height - thicknessOfBorder,
                                                    rectangleToDraw.Width,
                                                    thicknessOfBorder), null, borderColor, 0f, Vector2.Zero, SpriteEffects.None, 1.0f - .005f);
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            if(this.AABBColor==Color.Yellow || this.AABBColor== Color.Blue)
                spriteBatch.Draw(texture, AABB.Position, new Rectangle(currentFrame * FrameSize.X,  0, FrameSize.X, FrameSize.Y), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects, 0);
            else if(this.AABBColor==Color.Red)
                spriteBatch.Draw(texture, new Vector2(AABB.Position.X-2,AABB.Position.Y-2), new Rectangle(currentFrame * FrameSize.X, 0, FrameSize.X, FrameSize.Y), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects, 0);
            else
                spriteBatch.Draw(texture, new Vector2(AABB.Position.X + 2, AABB.Position.Y + 2), new Rectangle(currentFrame * FrameSize.X, 0, FrameSize.X, FrameSize.Y), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects, 0);
            if (DrawAABB)
                DrawBorder(spriteBatch, new Rectangle((int)AABB.Position.X, (int)AABB.Position.Y, (int)AABB.Width, (int)AABB.Height), 2, AABBColor);
        }
    }
}
