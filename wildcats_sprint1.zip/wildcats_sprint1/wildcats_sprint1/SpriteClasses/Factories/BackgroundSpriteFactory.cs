﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.SpriteClasses.ItemSprites;
using wildcats_sprint1.States;
namespace wildcats_sprint1.SpriteClasses.Factories
{
    class BackgroundSpriteFactory : SpriteFactory
    {
        public enum ItemSpriteID
        {
            smallHill = 0,
            largeHill = 1,
            smallCloud = 2,
            mediumCloud = 3,
            largeCloud = 4,
            smallBush = 5,
            mediumBush = 6,
            largeBush = 7,
            castle = 8
        }
        public override Sprite GenerateSprite(int type, int x, int y)
        {
            Sprite sprite;
            ItemSpriteID id = (ItemSpriteID)type;

            switch (id)
            {
                case ItemSpriteID.smallCloud:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/SmallCloud"), new Point(31,24), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.mediumCloud:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/MediumCloud"), new Point(47,24), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.largeCloud:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/LargeCloud"), new Point(63,24), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.smallHill:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/SmallHill"), new Point(47,19), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.largeHill:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/LargeHill"), new Point(79,35), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.smallBush:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/SmallBush"), new Point(31,16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.mediumBush:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/MediumBush"), new Point(47,16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.largeBush:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/LargeBush"), new Point(63,16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.castle:
                    sprite = new BackgroundSprite(Game1.Game.Content.Load<Texture2D>("Background/castle"), new Point(320, 376), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                default:
                    sprite = null;
                    break;
            }
            return sprite;
        }
    }
}
