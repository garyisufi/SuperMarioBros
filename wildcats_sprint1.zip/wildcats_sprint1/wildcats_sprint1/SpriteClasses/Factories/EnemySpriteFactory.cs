﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.States;

namespace wildcats_sprint1.SpriteClasses.Factories
{
    class EnemySpriteFactory : SpriteFactory
    {
        public enum EnemySpriteID
        {
            Goomba = 0,
            GreenKoopa = 1,
            RedKoopa = 2,
            Piranha = 3,
        }
        public override Sprite GenerateSprite(int type, int x, int y)
        {
            Sprite sprite;
            EnemySpriteID id = (EnemySpriteID)type;

            switch (id)
            {
                case EnemySpriteID.Goomba:
                    sprite = new EnemySprite(Game1.Game.Content.Load<Texture2D>("Characters/Enemies/GoombaSpriteNoBackground"),new Point(16,16),new Vector2(x, y),2,true);
                    break;
                case EnemySpriteID.GreenKoopa:
                    sprite = new EnemySprite(Game1.Game.Content.Load<Texture2D>("Characters/Enemies/KoopaTroopa"), new Point(15,24),new Vector2(x, y), 2, true);
                    break;
                case EnemySpriteID.RedKoopa:
                    sprite = new EnemySprite(Game1.Game.Content.Load<Texture2D>("Characters/Enemies/RedKoopaTroopa"), new Point(15, 24), new Vector2(x, y), 2, true);
                    break;
                case EnemySpriteID.Piranha:
                    sprite = new EnemySprite(Game1.Game.Content.Load<Texture2D>("Characters/Enemies/piranha"), new Point(16, 23), new Vector2(x, y), 2, true);
                    break;
                default:
                    sprite = null;
                    break;
            }
            return sprite;
        }
    }
}
