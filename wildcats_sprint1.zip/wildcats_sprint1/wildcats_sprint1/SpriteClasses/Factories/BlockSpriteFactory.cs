﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.States;

namespace wildcats_sprint1.SpriteClasses.Factories
{
    class BlockSpriteFactory:SpriteFactory
    {
        public enum BlockSpriteID
        {
            BrickBlock = 0,
            FloorBlock = 1,
            QuestionBlock = 2,
            StairBlock = 3,
            UsedBlock = 4,
            HiddenBlock = 5,
            WarpPipe = 6,
            MediumPipe = 7,
            LargePipe = 8,
            LongCrookedPipe = 9,
            GoalPole = 10,
            Flag = 11,
            InvertedFloorBlock = 12,
            InvertedBrokenBlock = 13,
            Castle = 14,
        }
        public override Sprite GenerateSprite(int type, int x, int y)
        {
            Sprite sprite;
            BlockSpriteID id = (BlockSpriteID)type;

            switch (id)
            {
                case BlockSpriteID.BrickBlock:
                    sprite = new BrickBlock(Game1.Game.Content.Load<Texture2D>("Blocks/brickBlock"),new Point(16,16),new Vector2(x, y));
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.FloorBlock:

                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/brokenBrick"), new Point(16, 16), new Vector2(x, y),1,false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.QuestionBlock:

                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/questionBlock"), new Point(16, 16), new Vector2(x, y),3,true);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.StairBlock:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/StairBlock"), new Point(16, 16), new Vector2(x, y),1,false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.UsedBlock:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/UsedBlock"), new Point(16, 16), new Vector2(x, y),1,false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.HiddenBlock:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/HiddenBlock"), new Point(16, 16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.HiddenBlock;
                    break;
                case BlockSpriteID.WarpPipe:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/WarpPipe"), new Point(32, 32), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.Pipe;
                    break;
                case BlockSpriteID.MediumPipe:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/MediumPipe"), new Point(32, 48), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.LargePipe:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/LargePipe"), new Point(32, 64), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.LongCrookedPipe:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/longCrookedPipe"), new Point(62, 208), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.GoalPole:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/GoalPole"), new Point(16, 168), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.Flag;
                    break;
                case BlockSpriteID.Flag:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/Flag"), new Point(16, 16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.Flag;
                    break;
                case BlockSpriteID.InvertedFloorBlock:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/invertedBlock"), new Point(16, 16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.InvertedBrokenBlock:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/invertedBroken"), new Point(16, 16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                case BlockSpriteID.Castle:
                    sprite = new BlockSprite(Game1.Game.Content.Load<Texture2D>("Blocks/castle"), new Point(80, 94), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.OtherBlock;
                    break;
                default:
                    sprite = null;
                    break;
            }
            return sprite;
        }
    }
}
