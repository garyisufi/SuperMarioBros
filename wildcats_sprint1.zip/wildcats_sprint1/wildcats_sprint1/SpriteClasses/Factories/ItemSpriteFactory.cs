﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.SpriteClasses.ItemSprites;
using wildcats_sprint1.States;
namespace wildcats_sprint1.SpriteClasses.Factories
{
    class ItemSpriteFactory:SpriteFactory
    {
        public enum ItemSpriteID
        {
            OneUpMushroom = 0,
            SuperMushroom = 1,
            FireFlower = 2,
            SuperStar = 3,
            Coin = 4,
            Fireball = 5
        }
        public override Sprite GenerateSprite(int type, int x, int y)
        {
            Sprite sprite;
            ItemSpriteID id = (ItemSpriteID)type;

            switch(id)
            {
                case ItemSpriteID.OneUpMushroom:
                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/OneUpShroom"),new Point(16,16),new Vector2(x,y),1,false);
                    sprite.whatAmI = Sprite.id.NoEffect;
                    break;
                case ItemSpriteID.SuperMushroom:

                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/Mushroom"), new Point(16, 16), new Vector2(x, y), 1, false);
                    sprite.whatAmI = Sprite.id.RedMushroom;
                    break;
                case ItemSpriteID.FireFlower:

                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/FireFlower"), new Point(16, 16), new Vector2(x, y), 4, true);
                    sprite.whatAmI = Sprite.id.FireFlower;
                    break;
                case ItemSpriteID.Coin:
                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/coinAnimated"),new Point(8,14),new Vector2(x, y), 5,true);
                    sprite.whatAmI = Sprite.id.Coin;
                    break;
                case ItemSpriteID.SuperStar:
                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/Star"),new Point(14,16),new Vector2(x, y), 4,true);
                    sprite.whatAmI = Sprite.id.Star;
                    break;
                case ItemSpriteID.Fireball:
                    sprite = new ItemSprite(Game1.Game.Content.Load<Texture2D>("Items/fire"), new Point(17, 12), new Vector2(x, y), 1, false);
                    break;
                default:
                    sprite = null;
                    break;
            }
            return sprite;
        }
    }
}
