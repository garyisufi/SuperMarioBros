﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using wildcats_sprint1.Interfaces;
using wildcats_sprint1.States;
using wildcats_sprint1.States.Actions;
using wildcats_sprint1.States.Powerups;

namespace wildcats_sprint1.SpriteClasses.Factories
{
    class MarioSpriteFactory : SpriteFactory
    {
        static public int MarioSpriteType(IMarioActionState currentActionState, IMarioPowerUpState currentPowerUpState)
        {
            int type = (int)eMarioSprite.StandingMario;
            if (currentActionState is MarioStandingState)
                type = (int)eMarioSprite.StandingMario;
            else
            if (currentActionState is MarioCrouchingState)
                type = (int)eMarioSprite.CrouchingMario;
            else
            if (currentActionState is MarioJumpingState)
                type = (int)eMarioSprite.JumpingMario;
            else
            if (currentActionState is MarioFallingState)
                type = (int)eMarioSprite.FallingMario;
            else
            if (currentActionState is MarioBouncingState)
                type = (int)eMarioSprite.BouncingMario;
            else
            if (currentActionState is MarioWalkingState)
                type = (int)eMarioSprite.WalkingMario;
            else
            if (currentActionState is MarioRunningState)
                type = (int)eMarioSprite.RunningMario;
            else
            if (currentActionState is MarioDyingState)
                type = (int)eMarioSprite.DyingMario;

            if (currentPowerUpState is MarioStandardState)
                type *= 1;
            else
            if (currentPowerUpState is MarioSuperState)
                type *= 10;
            else
            if (currentPowerUpState is MarioFireState)
                type *= 100;
            else
            if (currentPowerUpState is MarioInvincibleState)
                type *= 1000;
            else
            if (currentPowerUpState is MarioSuperInvincibleState)
                type *= 10000;

            return type;
        }
        static private MarioSpriteFactory _MarioSpriteFactory;
        public static MarioSpriteFactory DefaultMarioSpriteFactory
        {
            get
            {
                if (_MarioSpriteFactory == null)
                    _MarioSpriteFactory = new MarioSpriteFactory();
                return _MarioSpriteFactory;
            }
        }
        private enum eMarioSprite
        {
            
            StandingMario = 1,
            CrouchingMario = 2,
            JumpingMario = 3,
            FallingMario = 4,
            BouncingMario = 5,
            WalkingMario = 6,
            RunningMario = 7,
            DyingMario = 8,
            ClimbingMario = 9,

            StandingSuperMario = 10,
            CrouchingSuperMario = 20,
            JumpingSuperMario = 30,
            FallingSuperMario = 40,
            BouncingSuperMario = 50,
            WalkingSuperMario = 60,
            RunningSuperMario = 70,
            DyingSuperMario = 80,
            ClimbingSuperMario = 90,

            StandingFireMario = 100,
            CrouchingFireMario = 200,
            JumpingFireMario = 300,
            FallingFireMario = 400,
            BouncingFireMario = 500,
            WalkingFireMario = 600,
            RunningFireMario = 700,
            DyingFireMario = 800,
            ClimbingFireMario = 900,

            
            StandingInvincibleMario = 1000,
            CrouchingInvincibleMario = 2000,
            JumpingInvincibleMario = 3000,
            FallingInvincibleMario = 4000,
            BouncingInvincibleMario = 5000,
            WalkingInvincibleMario = 6000,
            RunningInvincibleMario = 7000,
            DyingInvincibleMario = 8000,
            ClimbingInvincibleMario = 9000,

            
            StandingSuperInvincibleMario = 10000,
            CrouchingSuperInvincibleMario = 20000,
            JumpingSuperInvincibleMario = 30000,
            FallingSuperInvincibleMario = 40000,
            BouncingSuperInvincibleMario = 50000,
            WalkingSuperInvincibleMario = 60000,
            RunningSuperInvincibleMario = 70000,
            DyingSuperInvincibleMario = 80000,
            ClimbingSuperInvincibleMario = 90000
        };
        public override Sprite GenerateSprite(int type, int x, int y)
        {
            return null;
        }
        public Sprite GenerateSprite(int type, int x, int y, bool flip)
        {
            eMarioSprite eType = (eMarioSprite)type;
            Sprite sprite = null;
            switch (eType)
            {
                case eMarioSprite.StandingMario:
                    sprite = new SmallIdle(Game1.Game.Content.Load<Texture2D>("Characters/Mario/rightFacingIdleStandardMario"),new Vector2(x, y), new Vector2(0,0), new Vector2(0, 0));
                    if(flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.CrouchingMario:
                    sprite = new SmallIdle(Game1.Game.Content.Load<Texture2D>("Characters/Mario/rightFacingIdleStandardMario"),new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.JumpingMario:
                    sprite = new SmallJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.FallingMario:
                    sprite = new SmallIdle(Game1.Game.Content.Load<Texture2D>("Characters/Mario/rightFacingIdleStandardMario"),new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.BouncingMario://Don't know whatAmI the hell bouncing is supposed to be
                    sprite = new SmallJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.WalkingMario:
                    sprite = new SmallWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.RunningMario:
                    sprite = new SmallWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.DyingMario:
                    sprite = new SmallDead(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.ClimbingMario:
                    sprite = new SmallClimb(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.StandingSuperMario:
                    sprite = new SuperIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.CrouchingSuperMario:
                    sprite = new SuperCrouch(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.JumpingSuperMario:
                    sprite = new SuperJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.FallingSuperMario:
                    sprite = new SuperIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.BouncingSuperMario:
                    sprite = new SuperJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.WalkingSuperMario:
                    sprite = new SuperRunning(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.RunningSuperMario:
                    sprite = new SuperRunning(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.DyingSuperMario:
                    sprite = null; //no class
                    break;

                case eMarioSprite.ClimbingSuperMario:
                    sprite = new SuperClimb(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.StandingFireMario:
                    sprite = new FireIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.CrouchingFireMario:
                    sprite = new FireCrouch(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.JumpingFireMario:
                    sprite = new FireJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.FallingFireMario:
                    sprite = new FireIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.BouncingFireMario:
                    sprite = new FireJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.WalkingFireMario:
                    sprite = new FireWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.RunningFireMario:
                    sprite = new FireWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.DyingFireMario:
                    sprite = new FireDead(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.ClimbingFireMario:
                    sprite = new FireClimb(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.StandingInvincibleMario:
                    sprite = new SmallStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.CrouchingInvincibleMario:
                    //                        sprite = new InvincibleMarioCrouchingSprite(XNATheatre.Theatre);
                    sprite = new SmallStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.JumpingInvincibleMario:
                    sprite = new SmallStarJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.FallingInvincibleMario:
                    sprite = new SmallStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.BouncingInvincibleMario:
                    sprite = new SmallStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.WalkingInvincibleMario:
                    sprite = new SmallStarWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.RunningInvincibleMario:
                    sprite = new SmallStarWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.DyingInvincibleMario:
                    sprite = null; //we don't have this class, not possible maybe?
                    break;

                case eMarioSprite.ClimbingInvincibleMario:
                    sprite = new SuperStarClimb(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.StandingSuperInvincibleMario:
                    sprite = new SuperStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.CrouchingSuperInvincibleMario:
                    sprite = new SuperStarCrouch(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.JumpingSuperInvincibleMario:
                    sprite = new SuperStarJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.FallingSuperInvincibleMario:
                    sprite = new SuperStarIdle(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.BouncingSuperInvincibleMario:
                    sprite = new SuperStarJump(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.WalkingSuperInvincibleMario:
                    sprite = new SuperStarWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.RunningSuperInvincibleMario:
                    sprite = new SuperStarWalk(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;

                case eMarioSprite.DyingSuperInvincibleMario:
                    sprite = new SuperStarDeath(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;
                case eMarioSprite.ClimbingSuperInvincibleMario:
                    sprite = new SuperStarClimb(new Vector2(x, y), new Vector2(0, 0), new Vector2(0, 0));
                    if (flip)
                    {
                        sprite.Direction = eDirection.Left;
                    }
                    else
                    {
                        sprite.Direction = eDirection.Right;
                    }
                    break;
            }
            return sprite;
        }
    }
}
