﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.SpriteClasses.Factories
{
    public abstract class SpriteFactory
    {
        public SpriteFactory()
        {

        }
        public abstract Sprite GenerateSprite(int type, int x, int y);
    }
}
