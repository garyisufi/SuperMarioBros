﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class SmallStarJump : MarioSprites
    {
        public SmallStarJump(Vector2 pos, int c, int mpf, int w, int h, bool flipDirection) : base(pos, c, mpf, w, h)
        {
            position = pos;
            frame = 0;
            MillisecondsPerFrame = mpf;
            TimeSinceLastFrame = 0;
            cols = c;
            direction = 1;
            height = h;
            width = w;
            texture = game.Content.Load<Texture2D>("superMarioInvincibleJump");
        }
        public override ISprite HandleLeft()
        {
            //Change nothing because you can't change the direction you face in midair
            return this;
        }
        public override ISprite HandleRight()
        {
            //Change nothing because you can't change the direction you face in midair
            return this;
        }
        public override ISprite HandleJump()
        {
            //Change nothing because you are already jumping
            return this;
        }
        public override ISprite HandleCrouch()
        {
            //Change nothing because you can't crouch in midair
            return this;
        }
        public override ISprite HandleDamage()
        {
            //Change nothing because you can't take damage as star mario
            return this;
        }
        public override ISprite HandleMushroom()
        {
            ISprite nextState = new SmallToSuperStarTransform(position, 6, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = "super";
            return this;
        }
        public override ISprite HandleStar()
        {
            ISprite nextState = new SmallJump(position, 16, 16, flip);

            return this;
        }
        public override ISprite HandleFire()
        {
            //change previous state for use in Timeout
            ISprite nextState = new SmallToSuperStarTransform(position, 6, MillisecondsPerFrame, 16, 32, flip);
            previousState = "fire";
            return this;
        }
        /*
        public override MarioSprites HandleTimeout()
        {
            ISprite nextState = new SmallJump();
            return nextState;
        }
        */
        public override ISprite HandleButtonRelease()
        {
            ISprite nextState = new SuperStarIdle(position, 3, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = previousState;
            return nextState;
        }
    }
}
