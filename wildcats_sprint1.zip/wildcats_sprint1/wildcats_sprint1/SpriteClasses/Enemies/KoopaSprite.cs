﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.SpriteClasses.Enemies
{
    class KoopaSprite : EnemySprite 
    {
        public KoopaSprite(Texture2D tex, Point size, Vector2 pos, int c, bool isAnimated) : base(tex, size, pos, c, isAnimated)
        {

        }
    }
}
