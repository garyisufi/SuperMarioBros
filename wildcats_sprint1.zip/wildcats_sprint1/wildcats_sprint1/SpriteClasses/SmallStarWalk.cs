﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    class SmallStarWalk : MarioSprites
    {
        public SmallStarWalk(Vector2 pos, int c, int mpf, int w, int h, bool flipDirection) : base(pos, c, mpf, w, h)
        {
            position = pos;
            frame = 0;
            MillisecondsPerFrame = mpf;
            TimeSinceLastFrame = 0;
            cols = c;
            direction = 1;
            height = h;
            width = w;
            flip = flipDirection;
            texture = game.Content.Load<Texture2D>("marioInvincibleWalk");
        }
        public override ISprite HandleLeft()
        {

            ISprite nextState = this;
            if (flip)
            {
                nextState = new SmallStarWalk(position, 3, 166, 16, 16, false);
            }
            return nextState;

            /*
ISprite nextState = this;
//Slide to stop if currently moving right
if (!flip)
{
    nextState = new SmallStarSlide(position, cols, MillisecondsPerFrame, width, height, true);
    nextState.previousState = previousState;
}
return nextState;
*/
        }
        public override ISprite HandleRight()
        {

            ISprite nextState = this;
            if (!flip)
            {
                nextState = new SmallStarWalk(position, 3, 166, 16, 16, true);
                nextState.previousState = previousState;
            }
            return nextState;
            /*ISprite nextState = this;
            if (flip)
            {
                nextState = new SmallStarSlide(position, cols, MillisecondsPerFrame, width, height, true);
                nextState.previousState = previousState;
            }
            return nextState;*/
        }
        public override ISprite HandleJump()
        {
            ISprite nextState = new SmallStarJump(position, 3, MillisecondsPerFrame, 16, 32, flip);
            return nextState;

        }
        public override ISprite HandleCrouch()
        {
            //Can't crouch while small
            return this;
        }
        public override ISprite HandleDamage()
        {
            //can't take damage
            return this;
        }
        public override ISprite HandleMushroom()
        {
            ISprite nextState = new SuperStarWalk(position, 3, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = "super";
            return this;
        }
        public override ISprite HandleStar()
        {
            ISprite nextState = SmallWalk(position, 3, 166, 16, 16, flip);
            return this;
        }
        public override ISprite HandleFire()
        {
            //Fire mario looks same as super in transformation
            MarioSprites nextState = new SuperStarWalk(position, 3, MillisecondsPerFrame, 16, 32, flip);
            previousState = "fire";
            return this;
        }
        /*
        public override MarioSprites HandleTimeout()
        {
            MarioSprites nextState = new SmallWalk();
            return nextState;
        }
        */
        public override ISprite HandleButtonRelease()
        {
            ISprite nextState = new SmallStarIdle(position, 3, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = previousState;
            return nextState;
        }
    }
}
