﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class SuperStarJump : MarioSprites
    {
        public SuperStarJump(Vector2 pos, Vector2 velo, Vector2 acc) : base(null, new Point(16, 32), 3, pos, velo, acc, true) { 

            texture = Game1.Game.Content.Load<Texture2D>("Characters/Mario/superMarioInvincibleJump");

        }

    }
}
