﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class SuperStarDeath : MarioSprites
    {
        //this class is here because there are some auto-death things, such as lava, in the game, but none are actually found in the first level so it may be removed
        public SuperStarDeath(Vector2 pos, Vector2 velo, Vector2 acc) : base(null, new Point(16, 32), 3, pos, velo, acc, true)
        {

            texture = game.Content.Load<Texture2D>("Characters/Mario/superMarioInvincibleDeath");

        }
    }
}
