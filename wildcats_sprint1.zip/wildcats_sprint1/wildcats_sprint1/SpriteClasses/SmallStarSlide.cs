﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class SmallStarSlide : MarioSprites
    {
        public SmallStarSlide(Vector2 pos, int c, int mpf, int w, int h, bool flipDirection) : base(pos, c, mpf, w, h)
        {
            position = pos;
            frame = 0;
            MillisecondsPerFrame = mpf;
            TimeSinceLastFrame = 0;
            cols = c;
            direction = 1;
            height = h;
            width = w;
            flip = flipDirection;
            texture = game.Content.Load<Texture2D>("superMarioInvincibleStopSlide");
        }
        public override ISprite HandleLeft()
        {
            ISprite nextState = this;
            if (!flip)
            {
                nextState = new SmallStarWalk(position, 3, MillisecondsPerFrame, 16, 32, true);
            }
            return this;
        }
        public override ISprite HandleRight()
        {
            ISprite nextState = this;
            if (flip)
            {
                nextState = new SmallStarWalk(position, 3, MillisecondsPerFrame, 16, 32, false);
            }
            return this;
        }
        public override ISprite HandleJump()
        {
            //Continue with this state
            return this;
        }
        public override ISprite HandleCrouch()
        {
            //Continue with this state
            return this;
        }
        public override ISprite HandleDamage()
        {
            //Continue with this state
            return this;
        }
        public override ISprite HandleMushroom()
        {
            //Continue with this state
            return this;
        }
        public override ISprite HandleStar()
        {
            ISprite nextState = new SmallSlide(position, 16, 16, flip);


            return this;
        }
        public override ISprite HandleFire()
        {
            //Continue with this state
            return this;
        }
        /*
        public override MarioSprites HandleTimeout()
        {
            MarioSprites nextState = new SmallSlide();
            return nextState;
        }
        */
        public override ISprite HandleButtonRelease()
        {
            ISprite nextState = new SmallStarIdle(position, 3, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = previousState;
            return nextState;
        }
    }
}
