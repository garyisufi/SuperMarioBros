﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    public class QuestionBlockSprite : BlockSprite
    {
        public QuestionBlockSprite(Vector2 pos) : base(null, new Point(16,16),pos,3,true)
        {
            texture = Game1.Game.Content.Load<Texture2D>("Blocks/QuestionBlock");
            whatAmI = id.QuestionBlock;
        }
        public void HitBlock()
        {
            texture = Game1.Game.Content.Load<Texture2D>("Blocks/UsedBlock");
            IsAnimated = false;
        }

    }
}
