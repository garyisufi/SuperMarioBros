﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    abstract class  MarioSprites : Sprite
    {
        protected Game1 game = Game1.Game;
        public MarioSprites(Texture2D texture,Point size, int col, Vector2 pos, Vector2 velo, Vector2 acc, bool isAnimated) : base(texture,size,col,pos,velo,acc,isAnimated,Color.Yellow)
        {
           
        }
    }
}
