﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    class SmallWalk : MarioSprites
    {
        public SmallWalk(Vector2 pos, Vector2 velo, Vector2 acc) : base(null, new Point(16, 16), 3, pos, velo, acc, true)
        {

            texture = game.Content.Load<Texture2D>("Characters/Mario/rightFacingStandardMarioRunning");
        }
    }
}
