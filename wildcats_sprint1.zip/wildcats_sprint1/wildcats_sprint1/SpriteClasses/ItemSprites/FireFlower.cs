﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.SpriteClasses.ItemSprites
{
    class FireFlower:ItemSprite
    {
            public FireFlower(Texture2D tex, Vector2 pos) : base(tex, new Point(16, 16), pos, 4, true)
            {

            }
        
    }
}
