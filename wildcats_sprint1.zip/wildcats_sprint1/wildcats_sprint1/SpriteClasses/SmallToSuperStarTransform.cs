﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    //For use in future
    class SmallToSuperStarTransform : MarioSprites
    {

        public SmallToSuperStarTransform(Vector2 pos, int c, int mpf, int w, int h, bool flipDirection) : base(pos, c, mpf, w, h)
        {
            position = pos;
            frame = 0;
            MillisecondsPerFrame = mpf;
            TimeSinceLastFrame = 0;
            cols = c;
            direction = 1;
            height = h;
            width = w;
            texture = game.Content.Load<Texture2D>("marioInvincibleIdle");
            flip = flipDirection;
        }

        public override ISprite HandleLeft()
        {
            //Can't move while this animation plays
            return this;
        }
        public override ISprite HandleRight()
        {
            //Can't move while this animation plays
            return this;
        }
        public override ISprite HandleJump()
        {
            //Can't move while this animation plays
            return this;
        }
        public override ISprite HandleCrouch()
        {
            //Can't crouch while small
            return this;

        }
        public override ISprite HandleDamage()
        {
            //Can't take damage
            return this;
        }
        public override ISprite HandleMushroom()
        {
            //Already getting mushroom
            return this;
        }
        public override ISprite HandleStar()
        {
            //already star
            return this;
        }
        public override ISprite HandleFire()
        {
            previousState = "fire";
            return this;
        }
        /*public override ISprite HandleTimeout()
        {
            ISprite nextState = new SuperIdle(position, 3, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = previousState;
            return nextState;
        }*/
        public override ISprite HandleButtonRelease()
        {
            return this;
        }

    }
}
