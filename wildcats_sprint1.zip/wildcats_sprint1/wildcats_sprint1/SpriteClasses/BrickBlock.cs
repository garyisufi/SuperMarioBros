﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using wildcats_sprint1.Collisions;

namespace wildcats_sprint1.SpriteClasses
{
    public class BrickBlock:BlockSprite
    {
        private bool isBroken;
        private BrickChunk[] bricks;
        int bump;
        public BrickBlock(Texture2D tex, Point size, Vector2 pos):base(tex,size,pos,1,false)
        {
            
            isBroken = false;
            bump = -5;
            bricks = new BrickChunk[4];
            bricks[0] = new BrickChunk(Game1.Game.Content.Load<Texture2D>("Blocks/BrickChunk"), new Point(8, 8), new Vector2(pos.X , pos.Y), new Vector2(-50, -50), new Vector2(0, 300));
            bricks[1] = new BrickChunk(Game1.Game.Content.Load<Texture2D>("Blocks/BrickChunk"), new Point(8, 8), new Vector2(pos.X + 8, pos.Y), new Vector2(50, -50), new Vector2(0, 300));
            bricks[2] = new BrickChunk(Game1.Game.Content.Load<Texture2D>("Blocks/BrickChunk"), new Point(8, 8), new Vector2(pos.X , pos.Y - 8), new Vector2(50, -50), new Vector2(0, 300));
            bricks[3] = new BrickChunk(Game1.Game.Content.Load<Texture2D>("Blocks/BrickChunk"),new Point(8,8),new Vector2(pos.X +8, pos.Y - 8), new Vector2(-50, -50), new Vector2(0, 300));
            whatAmI = id.BrickBlock;
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
                if (isBroken)
                {
                    for (int i = 0; i < 4; i++)
                    {

                        bricks[i].Update(gameTime, graphics);
                    }
                }
                if(bump>-4)
                {
                    if (bump > 0)
                    {
                        Position = new Vector2(Position.X, Position.Y - 1);
                    }
                    else
                    {
                        Position = new Vector2(Position.X, Position.Y + 1);
                    }
                bump--;
                }
                
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            if (isBroken)
            {
                for(int i = 0; i<4; i++)
                {
                    bricks[i].Draw(spriteBatch);
                }
            }
            else
            {
                base.Draw(spriteBatch);
            }
        }
        public void Break()
        {
            isBroken = true;
            AABB = new AABB(new Rectangle());
            Position = new Vector2(-123, 1234);
        }
        public void Bump()
        {
            bump = 4;
        }
    }
}
