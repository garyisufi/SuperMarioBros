﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class BrickChunk : Sprite
    {
        
        public BrickChunk(Texture2D tex, Point size, Vector2 pos,Vector2 velocity, Vector2 acceleration) : base(tex, size, 1, pos, velocity, acceleration, false, Color.Blue)
        {
            
        }
        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            Velocity += Acceleration * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
        }
    }
}
