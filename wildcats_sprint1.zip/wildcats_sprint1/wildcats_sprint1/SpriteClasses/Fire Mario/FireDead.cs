﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class FireDead : MarioSprites
    {
        public FireDead(Vector2 pos, Vector2 velo, Vector2 acc) : base(null, new Point(16, 32), 1, pos, velo, acc, false)
        {

            texture = game.Content.Load<Texture2D>("Characters/Mario/DeadMario");
        }

    }
}
