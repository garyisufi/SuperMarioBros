﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    class SmallStarIdle : MarioSprites 
    {

        public SmallStarIdle(Vector2 pos, int c, int mpf, int w, int h, bool flipDirection) : base(pos, c, mpf, w, h)
        {
            position = pos;
            frame = 0;
            MillisecondsPerFrame = mpf;
            TimeSinceLastFrame = 0;
            cols = c;
            direction = 1;
            height = h;
            width = w;
            texture = game.Content.Load<Texture2D>("marioInvincibleIdle");
            flip = flipDirection;
        }

        public override ISprite HandleLeft()
        {
            ISprite nextState = new SmallStarWalk(position, 3, MillisecondsPerFrame, 16, 32, true);
            nextState.previousState = previousState;
            return nextState;
        }
        public override ISprite HandleRight()
        {
            ISprite nextState = new SmallStarWalk(position, 3, MillisecondsPerFrame, 16, 32, false);
            nextState.previousState = previousState;
            return nextState;
        }
        public override ISprite HandleJump()
        {
            ISprite nextState = new SmallStarJump(position, 3, MillisecondsPerFrame, 16, 32, false);
            nextState.previousState = previousState;
            return nextState;
        }
        public override ISprite HandleCrouch()
        {
            //Can't crouch while small
            return this;

        }
        public override ISprite HandleDamage()
        {
            //Can't take damage
            return this;
        }
        public override ISprite HandleMushroom()
        {
            ISprite nextState = new SmallToSuperStarTransform(position, 6, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = "super";
            return nextState;
        }
        public override ISprite HandleStar()
        {
            ISprite nextState = new SmallIdle(position, 16, 16, flip);

            return this;
        }
        public override ISprite HandleFire()
        {
            //update previous state for timeout handling
            ISprite nextState = new SmallToSuperStarTransform(position, 6, MillisecondsPerFrame, 16, 32, flip);
            nextState.previousState = "fire";
            return nextState;
        }
        /*
        public override ISprite HandleTimeout()
        {
            ISprite nextState = new SmallIdle();
            return nextState;
        }
        */
        public override ISprite HandleButtonRelease()
        {
            return this;
        }


    }
}
