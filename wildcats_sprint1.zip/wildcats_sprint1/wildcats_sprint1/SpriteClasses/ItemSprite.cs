﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
   public class ItemSprite:Sprite
    {
        
        public ItemSprite(Texture2D tex, Point size, Vector2 pos, int c, bool isAnimated) : base(tex, size, c, pos, new Vector2(0, 0), new Vector2(0, 0), isAnimated, Color.Green)
        {

        }
    }
}

