﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using System.Threading.Tasks;

namespace wildcats_sprint1.SpriteClasses
{
    public class EnemySprite : Sprite
       
    {
        public EnemySprite(Texture2D tex, Point size, Vector2 pos, int c, bool isAnimated) : base(tex, size, c, pos, new Vector2(0, 0), new Vector2(0, 0), isAnimated, Color.Red)
        {
            whatAmI = id.Goomba;
        }
        public void die()//we know this isnt right btw. were not dumb. Just kinda tired and out of time. 
        {
            AABB = new Collisions.AABB(new Rectangle(0, 0, 0, 0));
            Position = new Vector2(-10000000, -1103203234);
        }
    }
}
