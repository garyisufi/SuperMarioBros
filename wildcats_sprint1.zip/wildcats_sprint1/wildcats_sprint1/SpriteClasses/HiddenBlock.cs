﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace wildcats_sprint1.SpriteClasses
{
    class HiddenBlock : BrickBlock
    {
        public HiddenBlock(Vector2 pos) : base(null, new Point(16,16), pos)
        {
            texture = Game1.Game.Content.Load<Texture2D>("Blocks/HiddenBlock");
        }
        public void HitBlock()
        {
            texture = Game1.Game.Content.Load<Texture2D>("Blocks/BrickBlock");
        }
    }
}


