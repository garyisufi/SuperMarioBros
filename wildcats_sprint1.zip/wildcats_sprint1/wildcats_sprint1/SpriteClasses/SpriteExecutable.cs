﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.SpriteClasses
{
    public class SpriteExecutable : Sprite
    {
        #region Properties

        private int colorBand = 0;
        private List<Point> offsetsColorBand = new List<Point>();

        private int timeSinceLastColorBand = 0;
        private int millisecondsPerColorBand = 100;

        public int MillisecondsPerColorBand
        {
            get { return millisecondsPerColorBand; }
            set { millisecondsPerColorBand = value; }
        }

        public int AddColorBand(Point offset)
        {
            offsetsColorBand.Add(offset);
            return offsetsColorBand.Count;
        }

        #endregion

        protected SpriteExecutable(Texture2D texture, Point frameSize, int sheetSize, Vector2 position, Vector2 velocity, Vector2 acceleration, bool isAnimated, Color type)
            : base(texture, frameSize, sheetSize, position, velocity, acceleration, isAnimated, type)
        {

        }

        protected override void NextFrame(GameTime gameTime)
        {
            if (offsetsColorBand.Count > 1)
            {
                timeSinceLastColorBand += gameTime.ElapsedGameTime.Milliseconds;
                if (timeSinceLastColorBand > MillisecondsPerColorBand)
                {
                    timeSinceLastColorBand -= MillisecondsPerColorBand;
                    colorBand++;
                    if (colorBand >= offsetsColorBand.Count) // Upper Limit Check
                    {
                        colorBand = 0;
                    }
                }
            }

            if (IsAnimated)
            {
                TimeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
                if (TimeSinceLastFrame > MillisecondsPerFrame)
                {
                    TimeSinceLastFrame -= MillisecondsPerFrame;

                    AnimationFrame += NextFrameIncrement;
                    if (NextFrameIncrement > 0 &&
                        AnimationFrame >= sheetSize)     // Upper Limit Check
                    {
                        if (IsAnimationFrameRecycling)
                        {
                            NextFrameIncrement *= -1;
                            AnimationFrame += NextFrameIncrement * 2;
                        }
                        else
                            AnimationFrame = 0;
                    }
                    else
                    if (NextFrameIncrement < 0 &&
                        AnimationFrame < 0)
                    {
                        if (IsAnimationFrameRecycling)
                        {
                            NextFrameIncrement *= -1;
                            AnimationFrame += NextFrameIncrement * 2;
                        }
                        else
                            AnimationFrame = 0;
                    }
                    currentFrame = AnimationFrame % sheetSize;
                }
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, AABB.Position, new Rectangle(offsetsColorBand[colorBand].X + currentFrame * FrameSize.X, offsetsColorBand[colorBand].Y + FrameSize.Y, FrameSize.X, FrameSize.Y), Color.White * 1.0f, 0, new Vector2(0, 0), 1, SpriteEffects, 1.0f);
            if (DrawAABB)
                DrawBorder(spriteBatch, new Rectangle((int)AABB.Position.X, (int)AABB.Position.Y, (int)AABB.Width, (int)AABB.Height), 2, AABBColor);
        }
    }
}
