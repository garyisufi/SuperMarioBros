﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace wildcats_sprint1.SpriteClasses
{
    class SuperJump : MarioSprites
    {
        public SuperJump(Vector2 pos, Vector2 velo, Vector2 acc) : base(null, new Point(16,32), 1, pos, velo, acc, false)
        {

            texture = game.Content.Load<Texture2D>("Characters/Mario/rightFacingSuperMarioJumping");

        }
    }
}
