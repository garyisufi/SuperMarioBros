﻿using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using System;
using wildcats_sprint1.Levels;
using System.IO;

namespace wildcats_sprint1.Levels
{
    public class LevelLoader
    {
        public LevelLoader()
        {
            string path = "../Levels";
            while (!Directory.Exists(path))
            {
                path = "../" + path;
            }
            Directory.SetCurrentDirectory(path);
        }

        public void Load()
        {
            LoadFloor();
            LoadEnemies();
            LoadItems();
            LoadBlocks();
            LoadMario();
            LoadBackground();
            LoadPipes();
        }

        public List<TileMap.FloorBlock> LoadFloor()
        {
            List<TileMap.FloorBlock> brickBottom = new List<TileMap.FloorBlock>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.FloorBlock>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                brickBottom = (List<TileMap.FloorBlock>)serializer.Deserialize(reader);
            }
            return brickBottom;
        }

        public List<TileMap.EnemyData> LoadEnemies()
        {
            List<TileMap.EnemyData> enemies = new List<TileMap.EnemyData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.EnemyData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                enemies = (List<TileMap.EnemyData>)serializer.Deserialize(reader);
            }
            return enemies;
        }

        public List<TileMap.ItemData> LoadItems()
        {
            List<TileMap.ItemData> items = new List<TileMap.ItemData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.ItemData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                items = (List<TileMap.ItemData>)serializer.Deserialize(reader);
            }
            return items;
        }
        public List<TileMap.BlockData> LoadBlocks()
        {
            List<TileMap.BlockData> blocks = new List<TileMap.BlockData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.BlockData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                blocks = (List<TileMap.BlockData>)serializer.Deserialize(reader);
            }
            return blocks;
        }
        public List<TileMap.QuestionBlockData> LoadQuestionBlocks()
        {
            List<TileMap.QuestionBlockData> blocks = new List<TileMap.QuestionBlockData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.QuestionBlockData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                blocks = (List<TileMap.QuestionBlockData>)serializer.Deserialize(reader);
            }
            return blocks;
        }
        public List<TileMap.BrickBlockData> LoadBrickBlocks()
        {
            List<TileMap.BrickBlockData> blocks = new List<TileMap.BrickBlockData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.BrickBlockData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                blocks = (List<TileMap.BrickBlockData>)serializer.Deserialize(reader);
            }
            return blocks;
        }
        public TileMap.MarioData LoadMario()
        {
            List<TileMap.MarioData> mario = new List<TileMap.MarioData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.MarioData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                mario = (List<TileMap.MarioData>)serializer.Deserialize(reader);
            }
            return mario[0];
        }
        public List<TileMap.Background> LoadBackground()
        {
            List<TileMap.Background> background = new List<TileMap.Background>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.Background>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                background = (List<TileMap.Background>)serializer.Deserialize(reader);
            }
            return background;
        }

        public List<TileMap.PipeData> LoadPipes()
        {
            List<TileMap.PipeData> pipe = new List<TileMap.PipeData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<TileMap.PipeData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/Level1.xml"))
            {
                pipe = (List<TileMap.PipeData>)serializer.Deserialize(reader);
            }
            return pipe;
        }
    }
}
