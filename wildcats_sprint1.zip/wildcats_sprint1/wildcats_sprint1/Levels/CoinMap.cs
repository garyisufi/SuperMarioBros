﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Levels
{
    public class CoinMap
    {
        public class ItemData
        {
            public int State;
            public int xLocation;
            public int yLocation;
        }
        public class BlockData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            
        }
        public class MarioData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            public int Flipped;

        }
    }
}
