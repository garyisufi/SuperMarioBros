﻿using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using System;
using wildcats_sprint1.Levels;
using System.IO;

namespace wildcats_sprint1.Levels
{
    public class CoinLoader
    {
        public CoinLoader()
        {
            string path = "../Levels";
            while (!Directory.Exists(path))
            {
                path = "../" + path;
            }
            Directory.SetCurrentDirectory(path);
        }

        public void Load()
        {
            LoadBlocks();
            LoadItems();
            LoadMario();
        }

        

        public List<CoinMap.ItemData> LoadItems()
        {
            List<CoinMap.ItemData> items = new List<CoinMap.ItemData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<CoinMap.ItemData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/CoinRoom.xml"))
            {
                items = (List<CoinMap.ItemData>)serializer.Deserialize(reader);
            }
            return items;
        }
        public List<CoinMap.BlockData> LoadBlocks()
        {
            List<CoinMap.BlockData> blocks = new List<CoinMap.BlockData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<CoinMap.BlockData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/CoinRoom.xml"))
            {
                blocks = (List<CoinMap.BlockData>)serializer.Deserialize(reader);
            }
            return blocks;
        }
        public CoinMap.MarioData LoadMario()
        {
            List<CoinMap.MarioData> mario = new List<CoinMap.MarioData>();
            XmlSerializer serializer = new XmlSerializer(typeof(List<CoinMap.MarioData>), new XmlRootAttribute("Map"));
            using (XmlReader reader = XmlReader.Create("../Levels/CoinRoom.xml"))
            {
                mario = (List<CoinMap.MarioData>)serializer.Deserialize(reader);
            }
            return mario[0];
        }
    }
}
