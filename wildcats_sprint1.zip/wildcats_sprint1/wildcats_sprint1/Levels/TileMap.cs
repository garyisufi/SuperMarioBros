﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Levels
{
    public class TileMap
    {
        public class FloorBlock
        {
            public string State;
            public string itemType;
            public int xLocation;
            public int yLocation;
        }

        public class EnemyData
        {
            public int State;
            public int xLocation;
            public int yLocation;
        }

        public class ItemData
        {
            public int State;
            public int xLocation;
            public int yLocation;
        }
        public class BlockData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            
        }
        public class PipeData
        {
            public int piranha;
            public int isTele;
            public int xLocation;
            public int yLocation;

        }
        public class QuestionBlockData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            public int containedItem;
            public int isHidden;
        }
        public class BrickBlockData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            public int numCoins;
            public int isHidden;
        }
        public class MarioData
        {
            public int State;
            public int xLocation;
            public int yLocation;
            public int Flipped;

        }
        public class Background
        {
            public int State;
            public int xLocation;
            public int yLocation;
        }
    }
}
