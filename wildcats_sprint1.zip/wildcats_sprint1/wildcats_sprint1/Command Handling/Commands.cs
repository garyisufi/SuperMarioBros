﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1.Command_Handling
{
        class ExitCommand : ICommand
        {
        protected Game1 receiver;
            public ExitCommand(Game1 receiver)
                : base()
            {
            this.receiver = receiver;
            }
            public void Execute()
            {
                receiver.ExitCommand();
            }
        }

        class ShowSpriteBordersCommand : ICommand
    {
        protected Game1 receiver;
            public ShowSpriteBordersCommand(Game1 receiver)
                : base()
            {
            this.receiver = receiver;
            }
            public void Execute()
            {
                receiver.ShowSpriteBordersCommand();
            }
        }

        class MarioStandCommand : ActionCommand
    {
            public MarioStandCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToStanding();
            }
        }
        class MarioCrouchCommand : ActionCommand
    {
            public MarioCrouchCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToCrouching();
            }
        }

        class MarioCrouchDiscontinueCommand : ActionCommand
    {
            public MarioCrouchDiscontinueCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.StopChangeToCrouch();
            }
        }
        class MarioJumpCommand : ActionCommand
    {
            public MarioJumpCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToJumping();
            }
        }

        class MarioJumpDiscontinueCommand : ActionCommand
    {
            public MarioJumpDiscontinueCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.StopChangeToJumping();
            }
        }

        class MarioFaceLeftCommand : ActionCommand
    {
            public MarioFaceLeftCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToLeftFacing();
            }
        }
        class MarioFaceLeftDiscontinueCommand : ActionCommand
    {
            public MarioFaceLeftDiscontinueCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.StopChangeToLeftFacing();
            }
        }

        class MarioFaceRightCommand : ActionCommand
    {
            public MarioFaceRightCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToRightFacing();
            }
        }

        class MarioFaceRightDiscontinueCommand : ActionCommand
    {
            public MarioFaceRightDiscontinueCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.StopChangeToRightFacing();
            }
        }

        class MarioStandardStateCommand : ActionCommand
    {
            public MarioStandardStateCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToStandardState();
            }
        }

        class MarioSuperStateCommand : ActionCommand
    {
            public MarioSuperStateCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToSuperState();
            }
        }
        class MarioFireStateCommand : ActionCommand
    {
            public MarioFireStateCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToFireState();
            }
        }
    class WarpCommand : ICommand
    {
        protected Mario receiver;
        public WarpCommand(Mario receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.Warp();
        }
    }
    class MarioStarStateCommand : ActionCommand
    {
            public MarioStarStateCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToStarState();
            }
        }


    class FireballCommand : ICommand
    {
        protected Game1 receiver;
        public FireballCommand(Game1 receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.FireballCommand();
        }
    }

    class MarioSuperStarStateCommand : ActionCommand
    {
            public MarioSuperStarStateCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ChangeToSuperStarState();
            }
        }

        class MarioTakeDamageCommand : ActionCommand
    {
            public MarioTakeDamageCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.TakeDamage();
            }
        }

        class MarioThrowProjectileCommand : ActionCommand
    {
            public MarioThrowProjectileCommand(Mario receiver)
                : base(receiver)
            {

            }
            public override void Execute()
            {
                receiver.ThrowFireball();
            }
        }
    class EnemyKillCommand : ICommand
    {
        protected EnemySprite receiver;
        public EnemyKillCommand(EnemySprite receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.die();
        }
    }
    class DisplayBoxCommand : ICommand
    {
        protected Game1 receiver;
        public DisplayBoxCommand(Game1 receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.Boxes();
        }
    }

    class MuteCommand : ICommand
    {
        protected Game1 receiver;
        public MuteCommand(Game1 receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.MuteCommand();
        }
    }

    class ResetCommand : ICommand
    {
        protected Game1 receiver;
        public ResetCommand(Game1 receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.ResetCommand(false);
        }
    }

    class PauseCommand : ICommand
    {
        protected Game1 receiver;
        public PauseCommand(Game1 receiver)
            : base()
        {
            this.receiver = receiver;
        }
        public void Execute()
        {
            receiver.Pause();
        }
    }
}
