﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Command_Handling
{
    class JumpCommand : ActionCommand
    {


        public JumpCommand(Mario receiver)
            : base(receiver)
        {

        }
        public override void Execute()
        {
            //receiver.JumpCommand();

        }
    }
}
