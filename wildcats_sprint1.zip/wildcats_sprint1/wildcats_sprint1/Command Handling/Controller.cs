﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Command_Handling
{
    public abstract class Controller : IController
    {
        public enum Action
        {
            // OldState     NewState    Description
            // --------     --------    -----------
            None,       // released     released    The key/button is not pressed at all.
            Down,       // released     pressed     The key/button has been pressed for the first time between the last Update and this on
            Held,       // pressed      pressed     The key/button is being held down.
            Released    // pressed      released    The key/button has been released since the previous Update
        }
       // protected Dictionary<int, ICommand> commands;
        protected Dictionary<int, ICommand> downCommands;   // <Key, Modifier>, ICommand
        protected Dictionary<int, ICommand> heldCommands;
        protected Dictionary <int, ICommand> releasedCommands;
        protected Dictionary<int, ICommand> commands;
        public Controller()
        {
           commands = new Dictionary<int, ICommand>();
            downCommands = new Dictionary<int, ICommand>();
            heldCommands = new Dictionary<int, ICommand>();
            releasedCommands = new Dictionary <int, ICommand>();
        }

        public void Command(int key, ICommand value, int action = (int)Action.Down)
        {
            if (!commands.ContainsKey(key))
            {
                commands.Add(key, value);
            }
            switch ((Action)action)
            {
                case Action.Down:
                    downCommands.Add(key, value);
                    break;
                case Action.Held:
                    heldCommands.Add(key, value);
                    break;
                case Action.Released:
                    releasedCommands.Add(key, value);
                    break;
            }

            }

        public abstract void UpdateInput();
    }
}
