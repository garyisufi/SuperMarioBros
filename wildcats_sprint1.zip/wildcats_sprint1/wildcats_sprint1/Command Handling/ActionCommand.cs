﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wildcats_sprint1.Objects;

namespace wildcats_sprint1.Command_Handling
{
    public interface ICommand
    {
        void Execute();
    }
    public abstract class ActionCommand : ICommand
    {
        protected Mario receiver;

        public ActionCommand(Mario receiver)
        {
            this.receiver = receiver;
        }
        public abstract void Execute();
    }

}
