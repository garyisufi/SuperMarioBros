﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Command_Handling
{
    class KeyboardController : Controller
    {
        Game1 game;
        KeyboardState previousKeyboardState;
        private List<Keypressed> _keysPressed;
        public KeyboardController(Game1 game)
            : base()
        {
            this.game = game;
            previousKeyboardState = Keyboard.GetState();
            _keysPressed = new List<Keypressed>();
        }
        class Keypressed
        {
            public Keys Key { get; set; }

            public Action Action { get; set; }
            public DateTime DateTime { get; set; }
            public Keypressed(Keys key, DateTime dateTime, Action action = Controller.Action.Down)
            {
                Key = key;
                Action = action;
                DateTime = dateTime;
            }
        }

        public override void UpdateInput()
        {
            // Get the current Keyboard state.
            KeyboardState currentState = Keyboard.GetState();

            Keys[] keysPressed = currentState.GetPressedKeys();
            foreach (Keypressed key in _keysPressed)
            {
                int index = Array.IndexOf(keysPressed, key.Key);
                if (index < 0)
                {
                    // Key was down last update, but not down now, so
                    // it has just been released.
                    if (releasedCommands.ContainsKey((int)key.Key))
                    {
                        releasedCommands[(int)key.Key].Execute();
                        key.DateTime = DateTime.MinValue;
                    }
                }
            }
            _keysPressed.RemoveAll(x => x.DateTime == DateTime.MinValue);
            foreach (Keys key in keysPressed)
            {
                if (!previousKeyboardState.IsKeyDown(key))
                {
                    if (downCommands.ContainsKey((int)key))
                    {
                        downCommands[(int)key].Execute();
                        _keysPressed.Add(new Keypressed(key, DateTime.Now));
                    }
                }
                else
                {
                    if (heldCommands.ContainsKey((int)key))
                    {
                        Keypressed match = _keysPressed.Find(p => p.Key == key);
                        if (match != null)
                        {
                            switch (match.Action)
                            {
                                case Controller.Action.Down:
                                        heldCommands[(int)key].Execute();
                                        match.DateTime = DateTime.Now;
                                        match.Action = Controller.Action.Held;
                                    break;
                                case Controller.Action.Held:
                                   
                                        heldCommands[(int)key].Execute();
                                        match.DateTime = DateTime.Now;
                                    
                                    break;
                            }
                        }
                    }
                }
            }
            // Update previous Keyboard state.
            previousKeyboardState = currentState;
        }
    }
}
