﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Command_Handling
{
    interface IController
    {
        void Command(int key, ICommand value, int action = 1);

        void UpdateInput();
    }
}
