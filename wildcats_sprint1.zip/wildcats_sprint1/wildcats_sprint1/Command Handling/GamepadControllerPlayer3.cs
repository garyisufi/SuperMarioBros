﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wildcats_sprint1.Command_Handling
{
    class GamepadControllerPlayer3 : Controller
    {
        Game1 game;
        GamePadState previousGamePadState, emptyInput;

        public GamepadControllerPlayer3(Game1 game)
            : base()
        {
            this.game = game;
            previousGamePadState = GamePad.GetState(PlayerIndex.Three);
            emptyInput = new GamePadState(Vector2.Zero, Vector2.Zero, 0, 0, new Buttons());
        }

        public override void UpdateInput()
        {
            // Get the current gamepad state.
            GamePadState currentState = GamePad.GetState(PlayerIndex.Three);

            // Process input only if connected.
            if (currentState.IsConnected)
            {
                if (currentState != emptyInput) // Button Pressed
                {

                    var buttonList = (Buttons[])Enum.GetValues(typeof(Buttons));

                    foreach (var button in buttonList)
                    {
                        if (currentState.IsButtonDown(button) &&
                            !previousGamePadState.IsButtonDown(button))
                            if (commands.ContainsKey((int)button))
                                commands[(int)button].Execute();
                    }
                }

                // Update previous gamepad state.
                previousGamePadState = currentState;
            }
        }
    }
}
