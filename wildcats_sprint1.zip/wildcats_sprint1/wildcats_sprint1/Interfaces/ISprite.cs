﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using wildcats_sprint1.Collisions;
using wildcats_sprint1.SpriteClasses;

namespace wildcats_sprint1
{
    public enum eDirection
    {
       Left, 
       Right
    }
    public interface ISprite
    {
        eDirection Direction { get; set; }
        Sprite Sprite { get; }
        AABB AABB { get; set; }
        Vector2 Velocity { get; set; }
        Vector2 Position { get; set; }
        Texture2D texture {get;set;}
        void Update(GameTime gameTime, GraphicsDeviceManager graphics);
        void Draw(SpriteBatch spriteBatch);

    }

}
